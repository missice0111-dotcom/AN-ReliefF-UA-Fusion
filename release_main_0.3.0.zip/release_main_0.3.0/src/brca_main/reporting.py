from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, balanced_accuracy_score, f1_score, log_loss, precision_recall_fscore_support, roc_auc_score
CLASSES=('Luminal A','Luminal B','HER2-enriched','Basal-like')
VARIANTS=('R0_MRNA_ONLY','R1_MULTIOMICS_S1','R2_ROUTE_B_S2','R3_C0C0_S2')
PROB_COLUMNS=tuple('probability::'+name for name in CLASSES)
METRICS=('macro_f1','accuracy','balanced_accuracy','macro_auc','log_loss','brier_multiclass')
CLASS_FIELDS=('precision','recall','f1','ovr_auc','TP','FP','FN','support','predicted_count')
PAIRS={'R2_vs_R0':VARIANTS[0],'R2_vs_R1':VARIANTS[1],'R2_vs_R3':VARIANTS[3]}
COMPARISON_LABELS={
    'R2_vs_R3':{'hypothesis':'H1','description':'AN-ReliefF versus Standard ReliefF'},
    'R2_vs_R0':{'hypothesis':'H2','description':'complete dual-omics workflow versus mRNA-only'},
    'R2_vs_R1':{'hypothesis':'H3','description':'UA-Fusion versus ordinary stacking'},
}

def read_json(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def read_tsv(path):return pd.read_csv(path,sep='\t',float_precision='round_trip',keep_default_na=False)


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1048576),b''):h.update(block)
    return h.hexdigest()


def atomic_text(path,text):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);temp=path.with_name(path.name+'.partial')
    temp.write_text(text,encoding='utf-8',newline='\n');os.replace(temp,path)


def write_tsv(path,frame):atomic_text(path,(frame if isinstance(frame,pd.DataFrame) else pd.DataFrame(frame)).to_csv(sep='\t',index=False,float_format='%.17g',lineterminator='\n'))


def write_json(path,value):atomic_text(path,json.dumps(value,ensure_ascii=False,sort_keys=True,indent=2,allow_nan=False)+'\n')


def require(condition,message):
    if not condition:raise RuntimeError('REPORT_STOP: '+message)


def validate_probability(frame):
    p=frame[list(PROB_COLUMNS)].to_numpy(dtype=float)
    require(p.shape==(len(frame),4) and np.isfinite(p).all() and ((p>=0)&(p<=1)).all(),'probability shape/finite/bounds')
    require(np.max(np.abs(p.sum(1)-1))<=1e-6,'probability row sum')
    require(np.array_equal(p.argmax(1),frame.predicted_label.to_numpy(dtype=int)),'probability argmax')
    require(frame.true_label.astype(int).isin(range(4)).all(),'class order/labels')
    return p


def metric_values(frame):
    p=validate_probability(frame);y=frame.true_label.to_numpy(int);pred=p.argmax(1)
    return dict(macro_f1=float(f1_score(y,pred,labels=range(4),average='macro',zero_division=0)),accuracy=float(accuracy_score(y,pred)),
        balanced_accuracy=float(balanced_accuracy_score(y,pred)),macro_auc=float(np.mean([roc_auc_score(y==c,p[:,c]) for c in range(4)])),
        log_loss=float(log_loss(y,p,labels=range(4))),brier_multiclass=float(((p-np.eye(4)[y])**2).sum(1).mean()))


def subtype_values(frame):
    p=validate_probability(frame);y=frame.true_label.to_numpy(int);pred=p.argmax(1)
    precision,recall,f1,support=precision_recall_fscore_support(y,pred,labels=range(4),zero_division=0);rows=[]
    for c,name in enumerate(CLASSES):
        actual=y==c;chosen=pred==c
        rows.append(dict(class_id=c,class_name=name,precision=float(precision[c]),recall=float(recall[c]),f1=float(f1[c]),
            ovr_auc=float(roc_auc_score(actual,p[:,c])),TP=int((actual&chosen).sum()),FP=int((~actual&chosen).sum()),
            FN=int((actual&~chosen).sum()),support=int(support[c]),predicted_count=int(chosen.sum())))
    return rows


def summary_frame(frame,keys,fields):
    rows=[]
    for key,small in frame.groupby(keys,sort=True):
        key=key if isinstance(key,tuple) else (key,);require(len(small)==3,'summary expects exactly three repeats '+str(key));row=dict(zip(keys,key));row['n_repeats']=3
        for field in fields:
            values=small[field].to_numpy(float);row[field+'_mean']=float(values.mean());row[field+'_sd']=float(values.std(ddof=1))
        rows.append(row)
    return pd.DataFrame(rows)


def performance(predictions):
    require(set(predictions.variant)==set(VARIANTS) and len(predictions)==8856,'four variants/8856 outer rows')
    require(not predictions.duplicated(['variant','repeat','patient_id']).any(),'duplicate repeat-level patient')
    repeats=[];classes=[];reference={}
    for (variant,repeat),small in predictions.groupby(['variant','repeat'],sort=True):
        require(repeat in (1,2,3) and len(small)==738 and small.patient_id.nunique()==738,'repeat roster738')
        require(small.true_label.astype(int).value_counts().to_dict()=={0:415,1:145,2:46,3:132},'class counts')
        require(set(small.outer_fold.astype(int))==set(range(1,6)),'five outer folds')
        roster=small.set_index('patient_id')[['true_label','outer_fold']].sort_index()
        if repeat in reference:require(roster.equals(reference[repeat]),'paired roster/labels/splits')
        else:reference[repeat]=roster
        repeats.append(dict(variant=variant,repeat=int(repeat),n_patients=738,**metric_values(small)))
        classes.extend(dict(variant=variant,repeat=int(repeat),**row) for row in subtype_values(small))
    repeats=pd.DataFrame(repeats);classes=pd.DataFrame(classes)
    return repeats,summary_frame(repeats,['variant'],METRICS),classes,summary_frame(classes,['variant','class_id','class_name'],CLASS_FIELDS)


def paired_tables(repeats):
    table=repeats.set_index(['variant','repeat']);result={}
    for name,right in PAIRS.items():
        rows=[]
        for metric in METRICS:
            delta=np.asarray([float(table.loc[(VARIANTS[2],r),metric]-table.loc[(right,r),metric]) for r in (1,2,3)])
            rows.append(dict(comparison=name,left_variant=right,right_variant=VARIANTS[2],delta_definition='right_minus_left',metric=metric,
                repeat_1=float(delta[0]),repeat_2=float(delta[1]),repeat_3=float(delta[2]),mean=float(delta.mean()),sample_sd=float(delta.std(ddof=1)),
                positive_repeat_count=int((delta>0).sum()),negative_repeat_count=int((delta<0).sum()),tie_repeat_count=int((delta==0).sum())))
        result[name]=pd.DataFrame(rows)
    return result


def describe_repeat_directions(pairs):
    """Describe paired repeat directions without assigning inferential meaning."""
    comparisons={}
    for pair,label in COMPARISON_LABELS.items():
        row=pairs[pair].loc[pairs[pair].metric=='macro_f1'].iloc[0]
        pattern=bool(row['mean']>0 and row.positive_repeat_count>=2)
        comparisons[pair]={**label,**{key:(int(row[key]) if key.endswith('_count') else float(row[key])) for key in ('repeat_1','repeat_2','repeat_3','mean','sample_sd','positive_repeat_count','negative_repeat_count','tie_repeat_count')},
                           'meets_descriptive_repeat_direction_rule':pattern}
    count=sum(row['meets_descriptive_repeat_direction_rule'] for row in comparisons.values())
    return {'positive_repeat_direction_comparison_count':count,'comparisons':comparisons,
        'primary_metric':'Macro-F1','delta_definition':'R2 minus comparator',
        'descriptive_rule':'mean delta strictly >0 AND at least2/3 repeat deltas strictly >0',
        'interpretation':'descriptive direction pattern only; not statistical significance or hypothesis proof',
        'same_cohort':True,'external_validation':False,'independent_patients':False,'summary_complete':True}
