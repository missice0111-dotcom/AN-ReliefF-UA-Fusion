"""Actual four-class main-analysis implementation, local release candidate."""
__version__ = "0.3.0"
