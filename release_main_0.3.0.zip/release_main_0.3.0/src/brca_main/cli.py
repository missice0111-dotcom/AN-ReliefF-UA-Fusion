"""Thin public command-line routing around the executed main algorithm."""
from __future__ import annotations
import argparse
from pathlib import Path
import shutil
import sys


def fresh_output(value, protected=(), *, create=True):
    output=Path(value).resolve()
    for item in protected:
        item=Path(item).resolve()
        if output==item or item.is_relative_to(output) or (item.is_dir() and output.is_relative_to(item)):
            raise RuntimeError('STOP: output would contain or overwrite an input/source location')
    if output.exists() and (not output.is_dir() or any(output.iterdir())):
        raise FileExistsError('Output must be new or empty')
    if create:
        output.mkdir(parents=True,exist_ok=True)
    return output


def prepare(args):
    from .common import CLASS_NAMES, file_hash, write_json
    from .input_contract import validate_cohort, validate_config
    from .preprocessing import _materialize_omic, _validate_pam50
    cohort=validate_cohort(args.cohort);validate_config(args.config)
    paths={'mrna':Path(args.mrna),'methyl':Path(args.methyl),'pam50':Path(args.pam50)}
    output=fresh_output(args.output,[*paths.values(),args.cohort,args.config,Path(__file__).parent])
    _validate_pam50(paths['pam50'],cohort).to_csv(output/'pam50_validation.tsv',sep='\t',index=False,lineterminator='\n')
    matrices={omic:_materialize_omic(paths[omic],cohort,omic,output,print) for omic in ('mrna','methyl')}
    sources=[{'omics':omic,'source_file':p.name,'sha256':file_hash(p),'source_size_bytes':p.stat().st_size} for omic,p in paths.items()]
    write_json(output/'dataset.json',{'status':'complete','schema_version':1,'n_patients':738,'patient_ids':list(cohort.patient_id),'class_order':list(CLASS_NAMES),'matrices':matrices,'source_audit':sources,'omics':['mrna','methyl'],'mirna_read_or_used':False,'cnv_read_or_used':False,'input_identity_note':'User-supplied molecular values; scientific contract conformity does not establish byte identity with the paper inputs.'})
    print('Prepared feature-major float32 input; no fold preprocessing or model fitting was performed.')


def train(args):
    from .common import file_hash, object_hash, write_json, scientific_environment
    from .input_contract import validate_cohort_splits, validate_config, validate_dataset
    from .data_pipeline import MainData
    from .training import Logger, run_context
    environment=scientific_environment()
    cohort,splits=validate_cohort_splits(args.cohort,args.splits)
    protocol=validate_config(args.config);validate_dataset(args.inputs,tuple(cohort.patient_id))
    source_dir=Path(__file__).parent
    output=fresh_output(args.output,[args.inputs,args.cohort,args.config,args.splits,source_dir])
    copies={'protocol/main_scientific_config.json':args.config,'splits/frozen_splits.json':args.splits,'inputs/cohort.tsv':args.cohort}
    for name,source in copies.items():
        dest=output/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,dest)
    identity={'status':'SCIENTIFIC_INPUTS_FROZEN_BEFORE_FITS','protocol_sha256':file_hash(output/'protocol/main_scientific_config.json'),'split_sha256':file_hash(output/'splits/frozen_splits.json'),'cohort_sha256':file_hash(output/'inputs/cohort.tsv'),'dataset_sha256':file_hash(args.inputs),'scientific_protocol_object_sha256':object_hash(protocol),'input_scope':'user_supplied_values_exact_released_cohort_and_frozen_splits','environment_versions':environment,'file_integrity':[{'source_file':p.name,'sha256':file_hash(p)} for p in sorted(source_dir.glob('*.py'))]}
    write_json(output/'audit/scientific_run_identity.json',identity)
    log=Logger(output)
    data=MainData(output,args.inputs,output/'inputs/cohort.tsv',output/'splits/frozen_splits.json',output/'protocol/main_scientific_config.json',log)
    try:
        data.prepare_audits()
        for r in (1,2,3):
            for o in range(1,6):run_context(output,data,protocol,identity,r,o,log)
        data.verify_sources()
        summarize_run(output,output/'inputs/cohort.tsv',output/'splits/frozen_splits.json',output/'aggregate')
        write_json(output/'COMPLETE.json',{'status':'PUBLIC_MAIN_RUN_COMPLETE','complete_contexts':15,'scientific_identity_sha256':object_hash(identity),'input_scope':'user_supplied_inputs','training_was_executed':True})
    finally:data.close()


def summarize_run(run,cohort_path,split_path,output):
    from .input_contract import validate_cohort_splits
    from . import reporting
    import pandas as pd
    cohort,splits=validate_cohort_splits(cohort_path,split_path)
    run=Path(run);output=Path(output)
    files=[run/'parts'/f'r{r}_o{o}'/'predictions.tsv' for r in (1,2,3) for o in range(1,6)]
    frames=[]; labels={p:i for p,i in zip(cohort.patient_id,(reporting.CLASSES.index(x) for x in cohort.subtype))}
    lookup={(int(f['repeat']),int(f['outer_fold'])):f for f in splits['folds']}
    for path in files:
        frame=reporting.read_tsv(path)
        reporting.validate_probability(frame)
        expected=path.parent.name.removeprefix('r').split('_o')
        reporting.require(frame.repeat.astype(int).eq(int(expected[0])).all() and frame.outer_fold.astype(int).eq(int(expected[1])).all(),'part grouping does not match its directory')
        for (variant,r,o),small in frame.groupby(['variant','repeat','outer_fold']):
            reporting.require(variant in reporting.VARIANTS,'unexpected method')
            reporting.require(set(small.patient_id)==set(lookup[int(r),int(o)]['test_patient_ids']),'outer prediction roster differs from frozen test partition')
            reporting.require(all(labels[p]==int(y) for p,y in zip(small.patient_id,small.true_label)),'prediction true labels differ')
        frames.append(frame)
    predictions=pd.concat(frames,ignore_index=True)
    repeats,summary,classes,class_summary=reporting.performance(predictions)
    output.mkdir(parents=True,exist_ok=True)
    for name,table in (('repeat_metrics.tsv',repeats),('summary_metrics.tsv',summary),('repeat_subtype_metrics.tsv',classes),('summary_subtype_metrics.tsv',class_summary)):
        reporting.write_tsv(output/name,table)
    pairs=reporting.paired_tables(repeats)
    for name,table in pairs.items():reporting.write_tsv(output/(name+'.tsv'),table)
    reporting.write_json(output/'direct_contrast_repeat_directions.json',reporting.describe_repeat_directions(pairs))
    print('Summarized existing complete precision predictions; no models were fit or predicted.')


def summarize(args):
    output=fresh_output(args.output,[args.run,args.cohort,args.splits,Path(__file__).parent],create=False)
    summarize_run(args.run,args.cohort,args.splits,output)


def parser():
    p=argparse.ArgumentParser(description='Four-subtype main analysis: actual preprocessing, AN-ReliefF, exact inner selection, XGBoost and UA-Fusion.')
    commands=p.add_subparsers(dest='command',required=True)
    prep=commands.add_parser('prepare',help='Materialize user-supplied raw matrices in the frozen cohort order; no model fitting.')
    for name in ('mrna','methyl','pam50','cohort','config','output'):prep.add_argument('--'+name,type=Path,required=True)
    prep.set_defaults(action=prepare)
    fit=commands.add_parser('train',help='Explicitly execute full main-model selection and repeated nested CV; expensive, not run during release preparation.')
    for name in ('inputs','config','cohort','splits','output'):fit.add_argument('--'+name,type=Path,required=True)
    fit.set_defaults(action=train)
    rec=commands.add_parser('summarize',help='Recompute metrics from a user-owned completed run without model fitting or prediction.')
    for name in ('run','cohort','splits','output'):rec.add_argument('--'+name,type=Path,required=True)
    rec.set_defaults(action=summarize)
    from .stats_cli import add_parser
    add_parser(commands)
    return p


def main(argv=None):
    args=parser().parse_args(argv)
    try:
        args.action(args)
    except KeyError:
        print('brca-main: error: required input field is missing',file=sys.stderr)
        raise SystemExit(2) from None
    except (OSError,ValueError,RuntimeError) as error:
        print('brca-main: error: '+str(error),file=sys.stderr)
        raise SystemExit(2) from None
