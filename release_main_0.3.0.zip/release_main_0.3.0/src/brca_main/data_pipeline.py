from __future__ import annotations
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
from time import perf_counter
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits
from .common import *
from . import preprocessing, geometry
from .clipped_geometry import ClippedEuclideanContext, feasibility as corrected_feasibility

KS=(3,5,7,10)
MULTIPLIERS=(2,3,4)
TOP_MS=(50,100,200,400)
PREPROCESSING_SOURCE=Path(preprocessing.__file__)
HISTORICAL_CORE=Path(geometry.historical.__file__)
GEOMETRY_SOURCE=Path(geometry.__file__)
CORRECTED_SOURCE=Path(__file__).parent/"clipped_geometry.py"
PREPROCESSING_SHA=file_hash(PREPROCESSING_SOURCE)
save_array=write_array

def transform_positions(raw,preprocessor,patient_ids,positions):
    """The exact accepted transform, for selected retained-feature positions."""
    positions=np.asarray(positions,dtype=np.int64);raw_indices=preprocessor.kept_indices_[positions]
    out=np.empty((len(patient_ids),len(positions)),dtype=np.float32)
    # Original transform chunks are 512 RAW features; preserve that arithmetic.
    block=preprocessor.block_features
    for start in np.unique((raw_indices//block)*block):
        stop=min(int(start)+block,raw.shape[0]);local=np.flatnonzero((raw_indices>=start)&(raw_indices<stop))
        values=raw.read_feature_block(patient_ids,int(start),stop)[:,raw_indices[local]-start].astype(np.float64)
        if preprocessor.omics=='mrna':values=np.log2(values+1.)
        values=np.where(np.isnan(values),preprocessor.fill_values_[positions[local]],values)
        values=(values-preprocessor.offsets_[positions[local]])/preprocessor.divisors_[positions[local]]
        require(np.isfinite(values).all(),'nonfinite frozen selected transform')
        out[:,local]=values.astype(np.float32)
    return out


def stream_anova(raw,preprocessor,train_ids,y,anova_function):
    """Same 1024 retained-column blocks as frozen anova_f_scores."""
    scores=np.empty(len(preprocessor.kept_indices_),dtype=np.float64);stream=[]
    for start in range(0,len(scores),1024):
        stop=min(start+1024,len(scores));X=transform_positions(raw,preprocessor,train_ids,np.arange(start,stop))
        scores[start:stop]=anova_function(X,y)
        stream.append({'retained_start':start,'retained_stop':stop,'transformed_float32_digest':array_digest(X)})
    return scores,stream


@dataclass
class CandidateContext:
    omic:str
    repeat:int
    outer_fold:int
    inner_fold:int|None
    train_ids:tuple
    validation_ids:tuple
    candidate_ids:tuple
    anova:np.ndarray
    X:np.ndarray
    Xv:np.ndarray|None
    y:np.ndarray
    yv:np.ndarray|None
    cache_key:str
    metadata:dict
    folder:Path
    @property
    def feature_ids(self):return self.candidate_ids
    @property
    def Xcandidate(self):return self.X
    @property
    def Xv_candidate(self):return self.Xv
    @property
    def train(self):return self.X
    @property
    def validation(self):return self.Xv


@dataclass
class TrainingContext:
    omic:str
    repeat:int
    outer_fold:int
    inner_fold:int|None
    train_ids:tuple
    validation_ids:tuple
    feature_ids:tuple
    X:np.ndarray
    Xv:np.ndarray|None
    y:np.ndarray
    yv:np.ndarray|None
    cache_key:str
    metadata:dict
    folder:Path
    family:str
    @property
    def feature_family(self):return self.family
    @property
    def selector_type(self):return self.family
    @property
    def model_train(self):return self.X
    @property
    def model_validation(self):return self.Xv

class MainData:
    def __init__(self,run,inputs,cohort_path,split_path,protocol_path,logger=print):
        self.run=Path(run).resolve();self.run_dir=self.run;self.logger=logger
        self._bindings={};self._contexts={};self._selected={};self._geometries={};self._ranks={};self._rows={};self._geometry_rows={};self._rank_rows={};self._selected_rows={};self._outer_access={};self._outer_arrays={}
        self.split_path=Path(split_path);self.protocol_path=Path(protocol_path)
        from .input_contract import validate_cohort_splits, validate_config, validate_dataset
        cohort,self.splits=validate_cohort_splits(cohort_path,self.split_path)
        self.patient_ids=tuple(cohort.patient_id);self.labels=dict(zip(cohort.patient_id,cohort.subtype))
        self.folds={(int(f['repeat']),int(f['outer_fold'])):f for f in self.splits['folds']}
        self.protocol=validate_config(self.protocol_path)
        self.banks=self.protocol['geometry_banks']
        self.bank_keys={family:{self._config_tuple(cfg) for cfg in rows} for family,rows in self.banks.items()}
        self.loader=preprocessing;self.geometry=geometry
        self.corrected_feasibility=corrected_feasibility;self.current_geometry=ClippedEuclideanContext
        inputs=Path(inputs);self.raw_metadata=validate_dataset(inputs,self.patient_ids)
        self.bind(inputs,role='user_supplied_dataset_metadata')
        self.bind(cohort_path,role='frozen_cohort')
        self.bind(self.split_path,role='frozen_splits')
        self.bind(self.protocol_path,role='scientific_configuration')
        for omic in ('mrna','methyl'):
            meta=self.raw_metadata['matrices'][omic]
            self.bind(inputs.parent/meta['matrix_file'],meta['npy_sha256'],role='user_supplied_float32_input')
            self.bind(inputs.parent/meta['feature_file'],meta['feature_file_sha256'],role='frozen_feature_order')
        self.raw={omic:self.loader.FeatureDataset(inputs.parent,omic,self.patient_ids,self.raw_metadata['matrices'][omic]) for omic in ('mrna','methyl')}
        self.identity={'status':'MAIN_INPUTS_PREPARED_ZERO_FITS','cohort_hash':lines_hash(self.patient_ids),'cohort_sha256':file_hash(cohort_path),'split_sha256':file_hash(self.split_path),'protocol_sha256':file_hash(self.protocol_path),
            'geometry_bank_sha256':object_hash(self.banks),'xgboost_bank_sha256':object_hash(self.protocol['xgboost_candidates']),'raw_dataset_sha256':file_hash(inputs),
            'raw_memmap_sha256':{o:self.raw_metadata['matrices'][o]['npy_sha256'] for o in self.raw},'raw_shapes':{o:self.raw_metadata['matrices'][o]['shape_features_by_patients'] for o in self.raw},
            'preprocessing_source_sha256':PREPROCESSING_SHA,'historical_core_sha256':file_hash(HISTORICAL_CORE),'geometry_source_sha256':file_hash(GEOMETRY_SOURCE),'corrected_geometry_source_sha256':file_hash(CORRECTED_SOURCE),'data_pipeline_sha256':file_hash(__file__),
            'reuse_scope':'user-supplied raw materialization and accepted arithmetic source only','old_learned_states_features_distances_models_reused':False,'full_new_training_contexts':120,'streamed_ANOVA_block':1024,'model_dtype':'float32','geometry_dtype':'float64','model_scaling':{'mrna':'historical_log2_median_training_z','methyl':'historical_median_beta_unscaled'}}
        self.identity_hash=object_hash(self.identity)

    def _science(self):
        science,sha=science_guard(self.run)
        require(file_hash(self.split_path)==self.identity['split_sha256'] and file_hash(self.protocol_path)==self.identity['protocol_sha256'],'split/config changed')
        return science,sha

    def bind(self,path,expected=None,role='source_artifact'):
        value=file_hash(path)
        require(expected is None or value==expected,'local source hash changed')
        self._bindings[str(Path(path).resolve())]=value
        return value

    @property
    def source_file_bindings(self):
        return [{'source_file':Path(p).name,'sha256':s} for p,s in sorted(self._bindings.items())]

    def verify_sources(self):
        self._science()
        for path,expected in self._bindings.items():
            require(file_hash(path)==expected,'scientific input changed during execution')
        return {'status':'PASS','identity_hash':self.identity_hash}

    @staticmethod
    def _id(k,c,r,m):return f"k{k:02d}_c{c if c is not None else 'NA'}_r{r if r is not None else 'NA'}_m{m:03d}"

    @staticmethod
    def _config_tuple(cfg):return int(cfg['k']),None if cfg.get('c') is None else int(cfg['c']),None if cfg.get('r') is None else int(cfg['r']),int(cfg['top_m']),cfg['config_id']

    def _config(self,family,cfg):
        family=str(family).upper();require(family in ('C0','C2'),'unknown selector family');key=self._config_tuple(cfg);require(key in self.bank_keys[family],'geometry config absent/different from prospectively frozen bank')
        return family,dict(zip(('k','c','r','top_m','config_id'),key))

    def labels_for(self,ids):return np.asarray([CLASS_NAMES.index(self.labels[x]) for x in ids],dtype=np.int64)

    def prepare_audits(self):
        immutable_json(self.run/'audit/base_data_identity.json',self.identity);immutable_json(self.run/'audit/base_data_source_bindings.json',self.source_file_bindings);return self.identity

    def _context_inputs(self,omic,r,o,i):
        require(omic in ('mrna','methyl') and (r,o) in self.folds,'unknown training context');f=self.folds[r,o]
        if i is None:return tuple(f['train_patient_ids']),tuple(f['test_patient_ids'])
        s=next(x for x in f['inner_folds'] if int(x['inner_fold'])==i);return tuple(s['train_patient_ids']),tuple(s['validation_patient_ids'])

    def _restore_preprocessor(self,m):
        pp=self.loader.FoldPreprocessor(omics=m['omic'])
        with np.load(m['state_path'],allow_pickle=False) as state:
            require(state['training_patient_ids'].tolist()==m['train_patient_ids'],'current PP saved train IDs differ')
            for attr,key in (('kept_indices_','kept_indices'),('fill_values_','fill_values'),('offsets_','offsets'),('divisors_','divisors'),('drop_reason_codes_','drop_reason_codes'),('missing_counts_','missing_counts'),('expressed_counts_','expressed_counts')):setattr(pp,attr,state[key].copy())
        pp.feature_ids_=tuple(self.raw[m['omic']].feature_ids[j] for j in pp.kept_indices_);pp.source_feature_ids_=tuple(self.raw[m['omic']].source_feature_ids[j] for j in pp.kept_indices_);pp.train_patient_ids_=tuple(m['train_patient_ids']);pp.audit_=m['preprocessing_audit']
        require(pp.state_digest()==m['preprocessing_state_hash'],'saved current PP state digest differs');return pp

    def context(self,omic,r,o,i=None):
        r,o=int(r),int(o);i=None if i is None else int(i);_,science=self._science();key=(omic,r,o,i)
        if key in self._contexts:return self._contexts[key]
        tr,pred=self._context_inputs(omic,r,o,i);y=self.labels_for(tr);raw=self.raw[omic]
        ident={'scientific_identity_hash':science,'data_identity_hash':self.identity_hash,'omic':omic,'repeat':r,'outer_fold':o,'inner_fold':i,'fit_patient_hash':lines_hash(tr),'prediction_patient_hash':lines_hash(pred),'split_sha256':self.identity['split_sha256'],'cohort_hash':lines_hash(self.patient_ids),'preprocessing_source_sha256':PREPROCESSING_SHA,'data_pipeline_sha256':file_hash(__file__),'candidate_limit':1000,'model_scaling':self.identity['model_scaling'][omic]}
        ck=object_hash(ident);folder=self.run/'cache/base_contexts'/omic/f'r{r}_o{o}'/('outer' if i is None else f'i{i}')/ck;marker=folder/'manifest.json';began=perf_counter();hit=marker.exists()
        if hit:
            m=read_json(marker);require(m['status']=='FRESH_ANOVA1000_CONTEXT_COMPLETE' and m['identity']==ident,'current fresh candidate cache identity differs')
            for ref in m['artifacts']:require(file_hash(ref['path'])==ref['sha256'],'current PP/ANOVA context artifact SHA differs')
            self._restore_preprocessor(m)
        else:
            folder.mkdir(parents=True,exist_ok=True);raw.set_access_scope(stage='current_newfold_training_PP_ANOVA_fit',allowed_patient_ids=tr,purpose='fresh_train_only_filters_median_model_scaling_ANOVA')
            pp=self.loader.FoldPreprocessor(omics=omic).fit(raw,tr);state=folder/'preprocessing_state.npz'
            with state.open('wb') as f:np.savez(f,kept_indices=pp.kept_indices_,fill_values=pp.fill_values_,offsets=pp.offsets_,divisors=pp.divisors_,drop_reason_codes=pp.drop_reason_codes_,missing_counts=pp.missing_counts_,expressed_counts=pp.expressed_counts_,training_patient_ids=np.asarray(tr,dtype=str))
            write_tsv(folder/'retained_features.tsv',{'feature_id':pp.feature_ids_,'source_feature_id':pp.source_feature_ids_,'source_feature_index':pp.kept_indices_})
            scores,blocks=stream_anova(raw,pp,tr,y,self.geometry.historical.anova_f_scores);save_array(folder/'full_anova_scores.npy',scores)
            ids=np.asarray(pp.feature_ids_,dtype=str);eligible=np.flatnonzero(np.isfinite(scores)|np.isposinf(scores));chosen=eligible[np.lexsort((ids[eligible],-scores[eligible]))][:1000];require(len(chosen)==1000,'fewer than fixed ANOVA1000 valid candidates')
            candidates=ids[chosen];anova=scores[chosen];X=transform_positions(raw,pp,tr,chosen);save_array(folder/'candidate_train.npy',X);save_array(folder/'candidate_anova.npy',anova);V=None
            if i is not None:
                before=pp.state_digest();raw.set_access_scope(stage='current_inner_validation_trainstate_transform',allowed_patient_ids=pred,purpose='validation_excluded_from_all_fit_steps')
                V=transform_positions(raw,pp,pred,chosen);save_array(folder/'candidate_validation.npy',V);require(pp.state_digest()==before,'inner validation altered current PP state')
            actual=[state,folder/'retained_features.tsv',folder/'full_anova_scores.npy',folder/'candidate_train.npy',folder/'candidate_anova.npy']
            if i is not None:actual.append(folder/'candidate_validation.npy')
            m={'status':'FRESH_ANOVA1000_CONTEXT_COMPLETE','identity':ident,'cache_key':ck,'omic':omic,'repeat':r,'outer_fold':o,'inner_fold':i,'train_patient_ids':list(tr),'prediction_patient_ids':list(pred),'candidate_feature_ids':candidates.tolist(),'anova_top1000_hash':lines_hash(candidates),'anova_feature_hash':lines_hash(candidates),'anova_retained_positions':chosen.tolist(),
                'state_path':str(state),'state_sha256':file_hash(state),'preprocessing_state_hash':pp.state_digest(),'preprocessing_audit':pp.audit_,'full_ANOVA_scores_path':str(folder/'full_anova_scores.npy'),'full_ANOVA_scores_sha256':file_hash(folder/'full_anova_scores.npy'),'ANOVA_fit_patient_hash':lines_hash(tr),'ANOVA_fit_labels_digest':array_digest(y),
                'streamed_training_transform_blocks':blocks,'streamed_transform_hash':object_hash(blocks),'X_train_digest':array_digest(X),'X_validation_digest':None if V is None else array_digest(V),'training_only_fit':True,'validation_overlap_n':0,'outer_test_accessed':False,'new_preprocessing_fit_count':1,'new_ANOVA_fit_count':1,'old_learned_contexts_reused':False,'preprocessing_seconds':perf_counter()-began,'artifacts':[{'path':str(p),'sha256':file_hash(p)} for p in actual]}
            write_json(marker,m)
        X=np.load(folder/'candidate_train.npy',mmap_mode='r',allow_pickle=False);V=None if i is None else np.load(folder/'candidate_validation.npy',mmap_mode='r',allow_pickle=False);anova=np.load(folder/'candidate_anova.npy',allow_pickle=False)
        require(X.dtype==np.float32 and X.shape==(len(tr),1000) and array_digest(X)==m['X_train_digest'],'current candidate train matrix differs')
        if V is not None:require(V.dtype==np.float32 and V.shape==(len(pred),1000) and array_digest(V)==m['X_validation_digest'],'current candidate validation matrix differs')
        ctx=CandidateContext(omic,r,o,i,tr,pred,tuple(m['candidate_feature_ids']),anova,X,V,y,None if i is None else self.labels_for(pred),ck,m,folder);self._contexts[key]=ctx
        self._rows[key]={'omic':omic,'repeat':r,'outer_fold':o,'inner_fold':i,'cache_key':ck,'fit_patient_hash':lines_hash(tr),'prediction_patient_hash':lines_hash(pred),'state_hash':m['preprocessing_state_hash'],'anova_feature_hash':m['anova_top1000_hash'],'manifest_path':str(marker),'manifest_sha256':file_hash(marker),'new_preprocessing_fit_count':1,'new_ANOVA_fit_count':1,'current_cache_hit':hit,'canonical_preprocessing_seconds':m['preprocessing_seconds'],'status':'PASS'};return ctx

    def shared_geometry(self,ctx):
        _,science=self._science();key=ctx.cache_key
        if key in self._geometries:return self._geometries[key]
        folder=ctx.folder/'geometry';hit=(folder/'distance_complete.json').exists()
        with threadpool_limits(limits=1):
            geom=self.geometry.load_context(ctx.X,ctx.y,ctx.train_ids,ctx.candidate_ids,ctx.anova,folder,ctx.cache_key,science) if hit else None
            if geom is None:geom=self.current_geometry(ctx.X,ctx.y,ctx.train_ids,ctx.candidate_ids,ctx.anova)
            else:geom.__class__=self.current_geometry
        receipt=self.geometry.save_context(geom,folder,ctx.cache_key,science);self._geometries[key]=(geom,receipt)
        self._geometry_rows[key]={'omic':ctx.omic,'repeat':ctx.repeat,'outer_fold':ctx.outer_fold,'inner_fold':ctx.inner_fold,'candidate_context_cache_key':key,'receipt_path':str(folder/'distance_complete.json'),'receipt_sha256':file_hash(folder/'distance_complete.json'),'distance_compute_count':1,'sorted_compute_count':1,'current_cache_hit':hit,'fit_patient_hash':lines_hash(ctx.train_ids),'distance_seconds':receipt['distance_seconds'],'sorted_seconds':receipt['sorted_seconds'],'status':'PASS'};return geom,receipt

    def feasibility(self,ctx,family,config):
        family,cfg=self._config(family,config)
        return self.corrected_feasibility(ctx.y,cfg['k'],cfg['c'],cfg['r'],mechanism=family,scale_scope='global_nonself',legacy_clipping=False)

    def rank(self,ctx,family,config):
        family,cfg=self._config(family,config);_,science=self._science();issues=self.feasibility(ctx,family,cfg)
        if issues:raise ValueError('INFEASIBLE_GEOMETRY: '+json.dumps(issues,sort_keys=True))
        who={k:cfg[k] for k in ('k','c','r')};geom,dreceipt=self.shared_geometry(ctx)
        ident={'scientific_identity_hash':science,'candidate_context_cache_key':ctx.cache_key,'family':family,'geometry':who,'metric':'training_z_standardized_euclidean','local_scale_scope':'global_nonself' if family=='C2' else None,'candidate_pool_clipping':family=='C2','geometry_core_sha256':self.identity['geometry_source_sha256'],'corrected_core_sha256':self.identity['corrected_geometry_source_sha256'],'preprocessing_state_hash':ctx.metadata['preprocessing_state_hash'],'ANOVA1000_hash':lines_hash(ctx.candidate_ids),'training_ids_hash':lines_hash(ctx.train_ids),'values_digest':array_digest(ctx.X.astype(np.float64)),'source_distance_receipt_sha256':file_hash(ctx.folder/'geometry/distance_complete.json')}
        key=object_hash(ident)
        if key in self._ranks:return self._ranks[key]
        folder=ctx.folder/'rankings'/family/f"k{cfg['k']:02d}_c{cfg['c'] if cfg['c'] is not None else 'NA'}_r{cfg['r'] if cfg['r'] is not None else 'NA'}";marker=folder/'rank_complete.json';hit=marker.exists()
        if hit:
            receipt=read_json(marker);require(receipt['status']=='TRAINING_RANK_COMPLETE' and receipt['identity']==ident,'current ranking cache identity differs')
            require(file_hash(receipt['array_path'])==receipt['array_sha256'],'current rank arrays SHA differs')
            with np.load(receipt['array_path'],allow_pickle=False) as a:
                require(a['training_patient_ids'].tolist()==list(ctx.train_ids) and np.array_equal(a['candidate_feature_ids'],ctx.candidate_ids) and np.array_equal(a['anova_scores'],ctx.anova),'saved rank source IDs/ANOVA differ')
                scores=a['full_relief_scores'].copy();neighbors=a['neighbors'].copy();ranking=self.geometry.historical._ranking(family,cfg['k'],np.asarray(ctx.candidate_ids),ctx.anova,scores,receipt['diagnostics'])
                require(np.array_equal(ranking.ranked_ids,a['ranked_ids']),'saved full rank order differs')
        else:
            with threadpool_limits(limits=1):ranking,neighbors,seconds=geom.rank(k=cfg['k'],c=cfg['c'],r=cfg['r'],mechanism=family,scale_scope='global_nonself',legacy_clipping=False,method=family)
            scales=np.empty(0,dtype=np.float64) if family=='C0' else geom._scale(cfg['r']*cfg['k'],'global_nonself');folder.mkdir(parents=True,exist_ok=True);path=folder/'ranking.npz'
            with path.open('wb') as f:np.savez(f,training_patient_ids=np.asarray(ctx.train_ids,dtype=str),candidate_feature_ids=np.asarray(ctx.candidate_ids,dtype=str),anova_scores=ctx.anova,neighbors=neighbors,global_scales=scales,full_relief_scores=ranking.relief_scores,ranked_ids=ranking.ranked_ids)
            receipt={'status':'TRAINING_RANK_COMPLETE','identity':ident,'rank_cache_key':key,'array_path':str(path),'array_sha256':file_hash(path),'neighbor_ids_digest':array_digest(neighbors),'local_scales_digest':array_digest(scales),'full_relief_scores_digest':array_digest(ranking.relief_scores),'ranked_feature_hash':lines_hash(ranking.ranked_ids),'diagnostics':ranking.diagnostics,'ranking_seconds':seconds,'distance_receipt_path':str(ctx.folder/'geometry/distance_complete.json'),'distance_receipt_sha256':ident['source_distance_receipt_sha256'],'new_distance_compute_count':0,'outer_test_accessed':False,'validation_used_for_rank':False,'training_ids_hash':lines_hash(ctx.train_ids),'preprocessing_state_hash':ctx.metadata['preprocessing_state_hash'],'scaler_state_sha256':{name:sha for name,sha in dreceipt['array_sha256'].items() if name.startswith('scaler_')}};write_json(marker,receipt)
        self._ranks[key]=(ranking,neighbors,receipt);self._rank_rows[key]={'omic':ctx.omic,'repeat':ctx.repeat,'outer_fold':ctx.outer_fold,'inner_fold':ctx.inner_fold,'family':family,**who,'rank_cache_key':key,'receipt_path':str(marker),'receipt_sha256':file_hash(marker),'array_path':receipt['array_path'],'array_sha256':receipt['array_sha256'],'fit_patient_hash':lines_hash(ctx.train_ids),'current_cache_hit':hit,'ranking_seconds':receipt['ranking_seconds'],'status':'PASS'};return self._ranks[key]

    def selected_context(self,ctx,family,config):
        family,cfg=self._config(family,config);ranking,neighbors,rreceipt=self.rank(ctx,family,cfg);features=tuple(map(str,ranking.ranked_ids[:cfg['top_m']]));lookup={v:j for j,v in enumerate(ctx.candidate_ids)};columns=[lookup[v] for v in features]
        ident={'scientific_identity_hash':ctx.metadata['identity']['scientific_identity_hash'],'candidate_context_cache_key':ctx.cache_key,'family':family,'geometry_config':cfg,'rank_cache_key':rreceipt['rank_cache_key'],'rank_array_sha256':rreceipt['array_sha256'],'fit_patient_hash':lines_hash(ctx.train_ids),'prediction_patient_hash':lines_hash(ctx.validation_ids),'ordered_feature_hash':lines_hash(features),'preprocessing_state_hash':ctx.metadata['preprocessing_state_hash'],'ANOVA1000_hash':lines_hash(ctx.candidate_ids)}
        key=object_hash(ident)
        if key in self._selected:return self._selected[key]
        folder=self.run/'cache/feature_contexts'/family/ctx.omic/f'r{ctx.repeat}_o{ctx.outer_fold}'/('outer' if ctx.inner_fold is None else f'i{ctx.inner_fold}')/key;marker=folder/'manifest.json';hit=marker.exists()
        if hit:
            m=read_json(marker);require(m['status']=='CURRENT_SELECTED_FEATURE_CONTEXT_COMPLETE' and m['identity']==ident,'current selected feature cache identity differs')
            for a in m['artifacts']:require(file_hash(a['path'])==a['sha256'],'current selected input array SHA differs')
        else:
            folder.mkdir(parents=True,exist_ok=True);X=np.ascontiguousarray(ctx.X[:,columns],dtype=np.float32);save_array(folder/'selected_train.npy',X);V=None
            if ctx.Xv is not None:V=np.ascontiguousarray(ctx.Xv[:,columns],dtype=np.float32);save_array(folder/'selected_validation.npy',V)
            actual=[folder/'selected_train.npy']+([] if V is None else [folder/'selected_validation.npy'])
            m={'status':'CURRENT_SELECTED_FEATURE_CONTEXT_COMPLETE','identity':ident,'cache_key':key,'candidate_context_cache_key':ctx.cache_key,'family':family,'geometry_config':cfg,'omic':ctx.omic,'repeat':ctx.repeat,'outer_fold':ctx.outer_fold,'inner_fold':ctx.inner_fold,'train_patient_ids':list(ctx.train_ids),'prediction_patient_ids':list(ctx.validation_ids),'feature_ids':list(features),'selected_feature_hash':lines_hash(features),'selected_candidate_columns':columns,'preprocessing_state_hash':ctx.metadata['preprocessing_state_hash'],'anova_top1000_hash':lines_hash(ctx.candidate_ids),'anova_feature_hash':lines_hash(ctx.candidate_ids),'candidate_manifest_path':str(ctx.folder/'manifest.json'),'candidate_manifest_sha256':file_hash(ctx.folder/'manifest.json'),'ranking_receipt_path':str(Path(rreceipt['array_path']).parent/'rank_complete.json'),'ranking_receipt_sha256':file_hash(Path(rreceipt['array_path']).parent/'rank_complete.json'),'geometry_receipt_path':rreceipt['distance_receipt_path'],'geometry_receipt_sha256':rreceipt['distance_receipt_sha256'],'X_train_digest':array_digest(X),'X_validation_digest':None if V is None else array_digest(V),'train_labels_digest':array_digest(ctx.y),'validation_labels_digest':None if ctx.yv is None else array_digest(ctx.yv),'training_only_fit':True,'validation_overlap_n':0,'outer_test_accessed':False,'artifacts':[{'path':str(p),'sha256':file_hash(p)} for p in actual]};write_json(marker,m)
        X=np.load(folder/'selected_train.npy',mmap_mode='r',allow_pickle=False);V=None if ctx.inner_fold is None else np.load(folder/'selected_validation.npy',mmap_mode='r',allow_pickle=False)
        require(X.dtype==np.float32 and np.array_equal(X,ctx.X[:,columns]) and array_digest(X)==m['X_train_digest'],'current selected training inputs/order differ')
        if V is not None:require(V.dtype==np.float32 and np.array_equal(V,ctx.Xv[:,columns]) and array_digest(V)==m['X_validation_digest'],'current selected validation inputs/order differ')
        selected=TrainingContext(ctx.omic,ctx.repeat,ctx.outer_fold,ctx.inner_fold,ctx.train_ids,ctx.validation_ids,features,X,V,ctx.y,ctx.yv,key,m,folder,family);self._selected[key]=selected
        self._selected_rows[key]={'omic':ctx.omic,'repeat':ctx.repeat,'outer_fold':ctx.outer_fold,'inner_fold':ctx.inner_fold,'family':family,'config_id':cfg['config_id'],'cache_key':key,'candidate_context_cache_key':ctx.cache_key,'ordered_feature_hash':lines_hash(features),'manifest_path':str(marker),'manifest_sha256':file_hash(marker),'fit_patient_hash':lines_hash(ctx.train_ids),'prediction_patient_hash':lines_hash(ctx.validation_ids),'current_cache_hit':hit,'status':'PASS'};return selected

    def transform_outer(self,selected,joint_lock):
        require(selected.inner_fold is None,'outer transformation requires full outer-training selected context');science,sha=self._science();joint_path=Path(joint_lock).resolve();require(self.run in joint_path.parents,'joint lock outside current run');joint=read_json(joint_path);r,o=selected.repeat,selected.outer_fold
        require(joint['status']=='META_PARAMETERS_AND_MODELS_LOCKED' and joint['scientific_identity_hash']==sha and joint['repeat']==r and joint['outer_fold']==o and joint['outer_training_ids_hash']==lines_hash(selected.train_ids) and joint['outer_test_accessed'] is False,'current full final joint model/parameter lock differs')
        variants=('R1_MULTIOMICS_S1','R2_ROUTE_B_S2','R3_C0C0_S2');require(set(joint['final_model_receipts'])==set(variants),'current all3 final meta models are not jointly locked')
        for variant,ref in joint['final_model_receipts'].items():
            path=Path(ref['path']).resolve();require(self.run in path.parents and file_hash(path)==ref['sha256'],'current final meta fitted receipt path/SHA differs');record=read_json(path);mi=record['identity']
            require(record['status']=='FITTED' and record['classes']==[0,1,2,3] and record['outer_test_accessed'] is False and mi['scientific_identity_hash']==sha and mi['repeat']==r and mi['outer_fold']==o and mi['phase']=='outer' and mi['meta_fold'] is None and mi['train_patient_ids']==list(selected.train_ids) and mi['train_patient_ids_hash']==lines_hash(selected.train_ids),'current full-outer final meta fit scope differs')
        ref=joint['base_selection_locks'][selected.omic];selection_path=Path(ref['path']).resolve();require(self.run in selection_path.parents and file_hash(selection_path)==ref['sha256'],'current selected geometry/shared-classifier lock SHA differs');sl=read_json(selection_path)
        require(sl['status']=='BASE_GEOMETRY_AND_XGB_LOCKED' and sl['scientific_identity_hash']==sha and sl['repeat']==r and sl['outer_fold']==o and sl['omic']==selected.omic and sl['selected_geometry'][selected.family]==selected.metadata['geometry_config'],'current selected-family geometry lock differs')
        require(sl['selected_xgb_config'] in self.protocol['xgboost_candidates'],'current shared XGB winner absent/different from original20 bank')
        candidate=self.context(selected.omic,r,o,None);require(candidate.cache_key==selected.metadata['candidate_context_cache_key'],'current outer selected context parent differs')
        feature_path=selected.folder/'outer_feature_lock.json';fl={'status':'CURRENT_OUTER_SELECTED_FEATURES_LOCKED','scientific_identity_hash':sha,'family':selected.family,'omic':selected.omic,'repeat':r,'outer_fold':o,'selected_context_cache_key':selected.cache_key,'candidate_context_cache_key':candidate.cache_key,'geometry_config':selected.metadata['geometry_config'],'ordered_feature_ids':list(selected.feature_ids),'ordered_feature_hash':lines_hash(selected.feature_ids),'joint_meta_lock_path':str(joint_path),'joint_meta_lock_sha256':file_hash(joint_path),'base_selection_lock_path':str(selection_path),'base_selection_lock_sha256':file_hash(selection_path),'outer_test_accessed':False};immutable_json(feature_path,fl)
        marker=selected.folder/'outer_transform.json';ident={'scientific_identity_hash':sha,'selected_context_cache_key':selected.cache_key,'candidate_context_cache_key':candidate.cache_key,'fit_patient_hash':lines_hash(selected.train_ids),'prediction_patient_hash':lines_hash(selected.validation_ids),'preprocessing_state_hash':candidate.metadata['preprocessing_state_hash'],'ordered_feature_hash':lines_hash(selected.feature_ids),'joint_meta_lock_sha256':file_hash(joint_path),'feature_lock_sha256':file_hash(feature_path)}
        if marker.exists():
            record=read_json(marker);require(record['identity']==ident and file_hash(record['array_path'])==record['array_sha256'],'current outer-transform cache differs')
        else:
            pp=self._restore_preprocessor(candidate.metadata);before=pp.state_digest();raw=self.raw[selected.omic];raw.set_access_scope(stage='current_outer_test_transform_after_allfinal_models_and_selectedfeatures_lock',allowed_patient_ids=selected.validation_ids,purpose='no_test_fit_no_test_labels_no_new_ANOVA_geometry')
            positions=np.asarray(candidate.metadata['anova_retained_positions'],dtype=np.int64)[selected.metadata['selected_candidate_columns']];V=transform_positions(raw,pp,selected.validation_ids,positions);require(pp.state_digest()==before,'outer transformation changed learned current training state');save_array(selected.folder/'selected_outer_test.npy',V)
            record={'status':'OUTER_TRANSFORM_ONLY_AFTER_CURRENT_JOINT_AND_FEATURE_LOCKS','identity':ident,'array_path':str(selected.folder/'selected_outer_test.npy'),'array_sha256':file_hash(selected.folder/'selected_outer_test.npy'),'array_digest':array_digest(V),'joint_meta_lock_path':str(joint_path),'feature_lock_path':str(feature_path),'base_selection_lock_path':str(selection_path),'new_refit':False,'training_state_unchanged':True,'test_used_for_ANOVA_or_geometry':False,'outer_test_labels_accessed':False};write_json(marker,record)
        V=np.load(record['array_path'],mmap_mode='r',allow_pickle=False);require(V.dtype==np.float32 and V.shape==(len(selected.validation_ids),len(selected.feature_ids)) and array_digest(V)==record['array_digest'],'current outer model prediction matrix differs')
        metadata={**selected.metadata,'outer_access':record,'X_validation_digest':record['array_digest'],'outer_transform_receipt_path':str(marker),'outer_transform_receipt_sha256':file_hash(marker)}
        transformed=TrainingContext(selected.omic,r,o,None,selected.train_ids,selected.validation_ids,selected.feature_ids,selected.X,V,selected.y,None,selected.cache_key,metadata,selected.folder,selected.family)
        self._outer_arrays[selected.cache_key]=(r,o,V)
        self._outer_access[selected.cache_key]={'omic':selected.omic,'repeat':r,'outer_fold':o,'family':selected.family,'selected_context_cache_key':selected.cache_key,'receipt_path':str(marker),'receipt_sha256':file_hash(marker),'joint_meta_lock_sha256':file_hash(joint_path),'current_fit_count':0,'test_labels_accessed':False,'status':'PASS'};return transformed

    def get_audit_tables(self):return {'contexts':list(self._rows.values()),'geometry':list(self._geometry_rows.values()),'ranking':list(self._rank_rows.values()),'selected_features':list(self._selected_rows.values()),'outer_transform':list(self._outer_access.values())}

    def flush_audits(self):
        """Rebuild only current-run metadata tables; preserve coverage on resume."""
        tables={key:[] for key in ('contexts','geometry','ranking','selected_features','outer_transform')}
        for p in sorted((self.run/'cache/base_contexts').rglob('manifest.json')):
            m=read_json(p);base={k:m[k] for k in ('omic','repeat','outer_fold','inner_fold')}
            tables['contexts'].append({**base,'cache_key':m['cache_key'],'fit_patient_hash':m['identity']['fit_patient_hash'],'prediction_patient_hash':m['identity']['prediction_patient_hash'],'state_hash':m['preprocessing_state_hash'],'anova_feature_hash':m['anova_top1000_hash'],'manifest_path':str(p),'manifest_sha256':file_hash(p),'new_preprocessing_fit_count':m['new_preprocessing_fit_count'],'new_ANOVA_fit_count':m['new_ANOVA_fit_count'],'canonical_preprocessing_seconds':m['preprocessing_seconds'],'status':'PASS'})
            dp=p.parent/'geometry/distance_complete.json'
            if dp.exists():
                d=read_json(dp);tables['geometry'].append({**base,'candidate_context_cache_key':m['cache_key'],'receipt_path':str(dp),'receipt_sha256':file_hash(dp),'fit_patient_hash':d['identity']['training_ids_hash'],'distance_compute_count':d['distance_compute_count'],'sorted_compute_count':d['sorted_compute_count'],'distance_seconds':d['distance_seconds'],'sorted_seconds':d['sorted_seconds'],'status':'PASS'})
            for rp in sorted((p.parent/'rankings').rglob('rank_complete.json')):
                a=read_json(rp);tables['ranking'].append({**base,'family':a['identity']['family'],**a['identity']['geometry'],'rank_cache_key':a['rank_cache_key'],'receipt_path':str(rp),'receipt_sha256':file_hash(rp),'array_path':a['array_path'],'array_sha256':a['array_sha256'],'fit_patient_hash':a['training_ids_hash'],'ranking_seconds':a['ranking_seconds'],'status':'PASS'})
        for p in sorted((self.run/'cache/feature_contexts').rglob('manifest.json')):
            m=read_json(p);base={k:m[k] for k in ('omic','repeat','outer_fold','inner_fold','family')}
            tables['selected_features'].append({**base,'config_id':m['geometry_config']['config_id'],'cache_key':m['cache_key'],'candidate_context_cache_key':m['candidate_context_cache_key'],'ordered_feature_hash':m['selected_feature_hash'],'manifest_path':str(p),'manifest_sha256':file_hash(p),'fit_patient_hash':m['identity']['fit_patient_hash'],'prediction_patient_hash':m['identity']['prediction_patient_hash'],'status':'PASS'})
            tp=p.parent/'outer_transform.json'
            if tp.exists():
                t=read_json(tp);tables['outer_transform'].append({**base,'selected_context_cache_key':m['cache_key'],'receipt_path':str(tp),'receipt_sha256':file_hash(tp),'joint_meta_lock_sha256':t['identity']['joint_meta_lock_sha256'],'current_fit_count':0,'test_labels_accessed':t['outer_test_labels_accessed'],'status':'PASS'})
        for name,rows in tables.items():write_tsv(self.run/'audit'/f'data_{name}_audit.tsv',rows)
        return tables

    def release_contexts(self,r,o):
        """Release current group RAM/memmap handles, leaving raw memmaps open."""
        r,o=int(r),int(o);keys={c.cache_key for c in self._contexts.values() if (c.repeat,c.outer_fold)==(r,o)}
        selected=[k for k,c in self._selected.items() if (c.repeat,c.outer_fold)==(r,o)]
        contexts=[k for k,c in self._contexts.items() if (c.repeat,c.outer_fold)==(r,o)]
        for c in [self._selected[k] for k in selected]+[self._contexts[k] for k in contexts]:
            for a in (c.X,c.Xv):
                mm=getattr(a,'_mmap',None)
                if mm is not None and not mm.closed:mm.close()
        for k,(rr,oo,a) in list(self._outer_arrays.items()):
            if (rr,oo)==(r,o):
                mm=getattr(a,'_mmap',None)
                if mm is not None and not mm.closed:mm.close()
                del self._outer_arrays[k]
        for k in selected:del self._selected[k]
        for k in contexts:del self._contexts[k]
        for k in keys:self._geometries.pop(k,None)
        for k,value in list(self._ranks.items()):
            if value[2]['identity']['candidate_context_cache_key'] in keys:del self._ranks[k]

    def close(self):
        for r,o in list(self.folds):self.release_contexts(r,o)
        for ctx in list(self._contexts.values())+list(self._selected.values()):
            for a in (ctx.X,ctx.Xv):
                mmap=getattr(a,'_mmap',None)
                if mmap is not None and not mmap.closed:mmap.close()
        self._contexts.clear();self._selected.clear();self._geometries.clear();self._ranks.clear()
        for raw in self.raw.values():raw.close()
