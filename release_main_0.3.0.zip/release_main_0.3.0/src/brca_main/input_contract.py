"""Public input routing and immutable scientific-contract checks; no model fitting."""
from __future__ import annotations
from collections import Counter
from pathlib import Path
import numpy as np
import pandas as pd
from .common import CLASS_NAMES, OUTER_SEEDS, SEEDS, SELECTION_SEQUENCE, VARIANTS
from .common import candidates, file_hash, lines_hash, object_hash, read_json, require
from .preprocessing import EXPECTED_FEATURES, FEATURE_FILE_HASHES
from .scientific_pins import CONFIG_OBJECT_SHA256, SPLITS_OBJECT_SHA256

PATIENT_ORDER_SHA256='3cf4b42e9796b98354cb1a8aaf9400c17c24748ce5880b33c69197da3830c0bd'
LABEL_ORDER_SHA256='30bc8b9b273f2bc1a9776ff2e1f895d899c2339d5268365778b2aa2d620aa96b'
COUNTS=(415,145,46,132)


def validate_cohort(path):
    cohort=pd.read_csv(path,sep='\t',dtype=str,keep_default_na=False)
    require({'patient_id','subtype','mrna_raw_column','methyl_raw_column'}.issubset(cohort.columns),'cohort input columns missing')
    ids=tuple(cohort.patient_id);labels=tuple(cohort.subtype)
    require(len(ids)==len(set(ids))==738,'cohort must contain 738 unique patients')
    require(tuple(Counter(labels).get(c,0) for c in CLASS_NAMES)==COUNTS and set(labels)==set(CLASS_NAMES),'fixed four-class counts differ')
    require(lines_hash(ids)==PATIENT_ORDER_SHA256 and lines_hash(labels)==LABEL_ORDER_SHA256,'frozen patient/label order differs')
    for omic in ('mrna','methyl'):
        values=cohort[omic+'_raw_column']
        require(not values.eq('').any() and not values.duplicated().any(),'sample mapping missing or duplicated')
        require(all(v.startswith(p+'-01') for p,v in zip(ids,values)),'primary-tumor sample mapping differs')
    return cohort


def validate_cohort_splits(cohort_path,split_path):
    cohort=validate_cohort(cohort_path);ids=tuple(cohort.patient_id);splits=read_json(split_path)
    require(object_hash(splits)==SPLITS_OBJECT_SHA256,'provided frozen split scientific content differs')
    require(splits['patient_order']==list(ids) and splits['class_order']==list(CLASS_NAMES),'split cohort/class order differs')
    folds={(int(f['repeat']),int(f['outer_fold'])):f for f in splits['folds']}
    require(set(folds)=={(r,o) for r in (1,2,3) for o in range(1,6)},'15 frozen outer folds required')
    seen={}
    for (r,o),f in folds.items():
        tr,te=f['train_patient_ids'],f['test_patient_ids']
        require(len(tr)==len(set(tr)) and len(te)==len(set(te)) and not set(tr)&set(te) and set(tr)|set(te)==set(ids),'outer split overlap/coverage')
        require(lines_hash(tr)==f['train_patient_ids_sha256'] and lines_hash(te)==f['test_patient_ids_sha256'],'outer patient order/hash differs')
        require(f['outer_seed']==OUTER_SEEDS[r-1] and f['inner_seed']==2026101200+100*r+o,'frozen seed rule differs')
        vals=[]
        require([int(x['inner_fold']) for x in f['inner_folds']]==[1,2,3],'three ordered inner folds required')
        for inner in f['inner_folds']:
            a,b=inner['train_patient_ids'],inner['validation_patient_ids']
            require(len(a)==len(set(a)) and len(b)==len(set(b)) and not set(a)&set(b) and set(a)|set(b)==set(tr),'inner split overlap/coverage')
            require(lines_hash(a)==inner['train_patient_ids_sha256'] and lines_hash(b)==inner['validation_patient_ids_sha256'],'inner patient order/hash differs')
            vals.extend(b)
        require(len(vals)==len(set(vals))==len(tr) and set(vals)==set(tr),'inner OOF coverage differs')
        seen.setdefault(r,[]).extend(te)
    require(set(seen)=={1,2,3} and all(len(v)==len(set(v))==738 and set(v)==set(ids) for v in seen.values()),'outer OOF repeat coverage differs')
    return cohort,splits


def validate_config(path):
    config=read_json(path)
    require(object_hash(config)==CONFIG_OBJECT_SHA256,'scientific configuration differs from the released final-method specification')
    require(tuple(config['selection_sequence'])==SELECTION_SEQUENCE,'selection order differs')
    banks=config['geometry_banks']
    require(len(banks['C0'])==16 and len(banks['C2'])==144,'real candidate-bank sizes differ')
    require(len(config['xgboost_candidates'])==20 and config['historical_anchor']==config['xgboost_candidates'][0]['parameters'],'reference XGB_00 or exact20 bank differs')
    for variant in VARIANTS[1:]:
        require(config['meta_grids'][variant]==candidates(variant),'meta candidate enumeration/order differs')
    require(tuple(config['xgboost']['paired_seeds'])==SEEDS and tuple(config['new_splits']['outer_seeds'])==OUTER_SEEDS,'random seeds differ')
    return config


def local_input_reference(directory,name):
    name=Path(name)
    require(not name.is_absolute() and name.drive=='' and '..' not in name.parts,'input reference must stay relative to its dataset folder')
    result=Path(directory)/name
    require(result.resolve().is_relative_to(Path(directory).resolve()),'input reference escapes its folder')
    return result


def validate_dataset(path,patient_ids):
    path=Path(path);meta=read_json(path)
    require(meta['status']=='complete' and meta['n_patients']==738 and meta['patient_ids']==list(patient_ids),'dataset cohort/order differs')
    require(meta['class_order']==list(CLASS_NAMES) and meta['omics']==['mrna','methyl'],'dataset class/omic order differs')
    require(meta['mirna_read_or_used'] is False and meta['cnv_read_or_used'] is False,'unsupported omic input')
    for omic in ('mrna','methyl'):
        m=meta['matrices'][omic]
        matrix=local_input_reference(path.parent,m['matrix_file']);features=local_input_reference(path.parent,m['feature_file'])
        require(m['shape_features_by_patients']==[EXPECTED_FEATURES[omic],738] and m['dtype']=='<f4','raw input dimension/dtype differs')
        require(file_hash(matrix)==m['npy_sha256'] and file_hash(features)==m['feature_file_sha256']==FEATURE_FILE_HASHES[omic],'materialized input checksum/feature order differs')
        raw=np.load(matrix,mmap_mode='r',allow_pickle=False)
        try: require(raw.shape==tuple(m['shape_features_by_patients']) and raw.dtype.str=='<f4','NPY shape/dtype differs')
        finally: raw._mmap.close()
    return meta
