"""Fixed-family LR fits with explicit training-row and scaler evidence."""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from time import perf_counter
import warnings
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.exceptions import ConvergenceWarning
from threadpoolctl import threadpool_limits
from .common import *

LR_FIXED={'penalty':'l2','solver':'lbfgs','class_weight':None,'max_iter':5000,'multi_class':'multinomial','tol':1e-4,'fit_intercept':True,'random_state':None}

@dataclass
class MetaFit:
    model:object
    scaler:object
    receipt:dict
    receipt_path:Path
    cache_key:str
    cache_hit:bool

def fit_meta(run, X, y, patient_ids, feature_names, config, context, phase, meta_fold, science_hash, oof_hash):
    run=Path(run);X=np.ascontiguousarray(X,dtype=np.float64);y=np.ascontiguousarray(y,dtype=np.int64);ids=list(map(str,patient_ids))
    if len(set(ids))!=len(ids) or X.shape!=(len(ids),config['meta_dim']) or len(y)!=len(ids) or set(np.unique(y))!={0,1,2,3} or not np.isfinite(X).all():raise RuntimeError('STOP: invalid LR training identity')
    identity={'scientific_identity_hash':science_hash,'base_oof_identity_hash':oof_hash,'repeat':int(context[0]),'outer_fold':int(context[1]),'phase':phase,'meta_fold':meta_fold,'subset_id':config['subset_id'],'C':float(config['C']),'meta_scaling':bool(config['meta_scaling']),'feature_names':list(feature_names),'feature_names_hash':lines_hash(feature_names),'train_patient_ids':ids,'train_patient_ids_hash':lines_hash(ids),'training_labels_digest':array_digest(y),'raw_training_matrix_digest':array_digest(X),'n_train':len(ids),'meta_dim':X.shape[1],'LR_fixed_parameters':LR_FIXED}
    key=object_hash(identity);folder=run/'model_cache'/phase/f'r{context[0]}_o{context[1]}';path=folder/(key+'.fit.json');scaler=None
    model=LogisticRegression(C=float(config['C']),**LR_FIXED)
    if path.exists():
        receipt=read_json(path)
        if receipt['status']!='FITTED' or receipt['identity']!=identity:raise RuntimeError('STOP: LR fit cache mismatch')
        if bool(config['meta_scaling']):
            sr=receipt['scaler'];scaler=StandardScaler();scaler.mean_=np.array(sr['mean'],dtype=np.float64);scaler.var_=np.array(sr['var'],dtype=np.float64);scaler.scale_=np.array(sr['scale'],dtype=np.float64);scaler.n_samples_seen_=int(sr['n_samples_seen']);scaler.n_features_in_=X.shape[1]
            if not np.array_equal(scaler.mean_,X.mean(0)) and not np.allclose(scaler.mean_,X.mean(0),rtol=0,atol=1e-15):raise RuntimeError('STOP: cached scaler training rows mismatch')
        model.classes_=np.array(receipt['classes'],dtype=np.int64);model.coef_=np.array(receipt['coef'],dtype=np.float64);model.intercept_=np.array(receipt['intercept'],dtype=np.float64);model.n_iter_=np.array(receipt['n_iter'],dtype=np.int32);model.n_features_in_=X.shape[1]
        if model.get_params()!=receipt['observed_parameters']:raise RuntimeError('STOP: LR cached full parameters differ')
        return MetaFit(model,scaler,receipt,path,key,True)
    scale_seconds=0.;started=perf_counter();transformed=X
    if config['meta_scaling']:
        scaler=StandardScaler();transformed=scaler.fit_transform(X);scale_seconds=perf_counter()-started
        if int(scaler.n_samples_seen_)!=len(ids) or not np.isfinite(transformed).all():raise RuntimeError('STOP: LR scaler failed')
    with threadpool_limits(limits=1),warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always');started=perf_counter();model.fit(transformed,y);fit_seconds=perf_counter()-started
    bad=[str(w.message) for w in caught if issubclass(w.category,ConvergenceWarning)]
    if bad or np.any(model.n_iter_>=5000) or not np.array_equal(model.classes_,np.arange(4)) or not np.isfinite(model.coef_).all() or not np.isfinite(model.intercept_).all():raise RuntimeError('STOP: LR convergence/classes/coefficient failure')
    sr=None if scaler is None else {'mean':scaler.mean_.tolist(),'var':scaler.var_.tolist(),'scale':scaler.scale_.tolist(),'n_samples_seen':int(scaler.n_samples_seen_),'n_features_in':int(scaler.n_features_in_),'fit_patient_ids_hash':lines_hash(ids),'fit_rows':len(ids)}
    receipt={'status':'FITTED','identity':identity,'cache_key':key,'explicit_parameters':{**LR_FIXED,'C':float(config['C'])},'observed_parameters':model.get_params(),'classes':model.classes_.tolist(),'coef':model.coef_.tolist(),'intercept':model.intercept_.tolist(),'n_iter':model.n_iter_.tolist(),'scaler':sr,'transformed_training_matrix_digest':array_digest(transformed),'fit_seconds':fit_seconds,'scaler_fit_seconds':scale_seconds,'convergence_warning_count':0,'outer_test_accessed':False,'fit_api':'sklearn.LogisticRegression.fit(X[explicit train IDs],y[explicit train IDs])','blas_threads':1}
    immutable_json(path,receipt)
    return MetaFit(model,scaler,receipt,path,key,False)

def predict_meta(run,fit,X,patient_ids,phase,meta_fold,joint_lock=None):
    X=np.ascontiguousarray(X,dtype=np.float64);ids=list(map(str,patient_ids));model=fit.model
    if X.shape!=(len(ids),model.n_features_in_) or not np.isfinite(X).all() or len(set(ids))!=len(ids):raise RuntimeError('STOP: LR prediction input failed')
    if phase!=fit.receipt['identity']['phase'] or set(ids)&set(fit.receipt['identity']['train_patient_ids']):raise RuntimeError('STOP: META_OOF_LEAKAGE=TRUE')
    if phase=='outer' and joint_lock is None:raise RuntimeError('STOP: joint meta model lock required')
    if phase=='outer':
        lock=read_json(joint_lock)
        if lock['status']!='META_PARAMETERS_AND_MODELS_LOCKED' or lock['scientific_identity_hash']!=fit.receipt['identity']['scientific_identity_hash'] or not any(x['path']==str(fit.receipt_path) and x['sha256']==file_hash(fit.receipt_path) for x in lock['final_model_receipts'].values()):raise RuntimeError('STOP: current final model not in joint lock')
    identity={'fit_receipt_path':str(fit.receipt_path),'fit_receipt_sha256':file_hash(fit.receipt_path),'fit_cache_key':fit.cache_key,'prediction_patient_ids':ids,'prediction_patient_ids_hash':lines_hash(ids),'raw_prediction_matrix_digest':array_digest(X),'phase':phase,'meta_fold':meta_fold,'joint_meta_lock_path':None if joint_lock is None else str(joint_lock),'joint_meta_lock_sha256':None if joint_lock is None else file_hash(joint_lock)}
    key=object_hash(identity);folder=fit.receipt_path.parent;path=folder/(key+'.prediction.json');npypath=folder/(key+'.npy')
    if path.exists():
        receipt=read_json(path)
        if receipt['identity']!=identity or receipt['status']!='COMPLETE' or file_hash(npypath)!=receipt['prediction_sha256']:raise RuntimeError('STOP: LR prediction cache mismatch')
        p=np.load(npypath,allow_pickle=False)
        if array_digest(p)!=receipt['prediction_digest']:raise RuntimeError('STOP: LR prediction digest differs')
        guard=probability_guard(p,len(ids),model.classes_)
        return p,receipt,{**guard,'prediction_cache_key':key,'phase':phase,'meta_fold':meta_fold,'prediction_path':str(npypath),'prediction_sha256':receipt['prediction_sha256']},True
    started=perf_counter()
    with threadpool_limits(limits=1):
        transformed=X if fit.scaler is None else fit.scaler.transform(X);p=np.asarray(model.predict_proba(transformed),dtype=np.float64)
    seconds=perf_counter()-started;guard=probability_guard(p,len(ids),model.classes_);write_array(npypath,p)
    receipt={'status':'COMPLETE','identity':identity,'prediction_cache_key':key,'prediction_path':str(npypath),'prediction_sha256':file_hash(npypath),'prediction_digest':array_digest(p),'transformed_prediction_matrix_digest':array_digest(transformed),'predict_seconds':seconds,'guard':guard}
    immutable_json(path,receipt)
    return p,receipt,{**guard,'prediction_cache_key':key,'phase':phase,'meta_fold':meta_fold,'prediction_path':str(npypath),'prediction_sha256':receipt['prediction_sha256']},False

def model_index(fit, prediction_receipt, config, context, phase, meta_fold):
    key=prediction_receipt['prediction_cache_key'];folder=fit.receipt_path.parent
    return {'repeat':context[0],'outer_fold':context[1],'phase':phase,'meta_fold':meta_fold,'config_id':config['config_id'],'subset_id':config['subset_id'],'C':config['C'],'meta_scaling':config['meta_scaling'],'meta_dim':config['meta_dim'],'fit_cache_key':fit.cache_key,'fit_receipt_path':str(fit.receipt_path),'fit_receipt_sha256':file_hash(fit.receipt_path),'prediction_cache_key':key,'prediction_receipt_path':str(folder/(key+'.prediction.json')),'prediction_receipt_sha256':file_hash(folder/(key+'.prediction.json')),'prediction_path':prediction_receipt['prediction_path'],'prediction_sha256':prediction_receipt['prediction_sha256'],'canonical_fit_seconds':fit.receipt['fit_seconds'],'canonical_scaler_fit_seconds':fit.receipt['scaler_fit_seconds'],'current_fit_seconds':0. if fit.cache_hit else fit.receipt['fit_seconds'],'current_fit_cache_hit':fit.cache_hit}

def coefficient_rows(fit,variant,repeat,outer,config):
    sr=fit.receipt['scaler'];names=fit.receipt['identity']['feature_names'];means=np.zeros(len(names)) if sr is None else np.array(sr['mean']);scales=np.ones(len(names)) if sr is None else np.array(sr['scale']);rows=[]
    for class_id,class_name in enumerate(CLASS_NAMES):
        coef=np.array(fit.receipt['coef'][class_id]);intercept=float(fit.receipt['intercept'][class_id]);raw=coef/scales;ri=float(intercept-np.sum(coef*means/scales))
        for j,name in enumerate(names):
            rows.append({'variant':variant,'repeat':repeat,'outer_fold':outer,'config_id':config['config_id'],'subset_id':config['subset_id'],'C':config['C'],'class_id':class_id,'class_name':class_name,'feature_id':name,'feature_role':'RNA_uncertainty' if j>=8 else 'base_probability','coefficient':float(coef[j]),'intercept':intercept,'meta_scaling':bool(config['meta_scaling']),'scaler_mean':float(means[j]),'scaler_scale':float(scales[j]),'coefficient_raw_space':float(raw[j]),'intercept_raw_space':ri,'fit_receipt_path':str(fit.receipt_path),'fit_receipt_sha256':file_hash(fit.receipt_path)})
    return rows
