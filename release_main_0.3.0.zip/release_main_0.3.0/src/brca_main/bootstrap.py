"""Final main-result patient-cluster bootstrap, extracted from the actual script.

Pure numerical functions and the computation block retain the original source.
Input validation and output routing are separate public adapters. Importing this
module performs no input reads, model operations or resampling.
"""
from __future__ import annotations
import time
import numpy as np

METHODS = ("R0_MRNA_ONLY", "R1_MULTIOMICS_S1", "R2_ROUTE_B_S2", "R3_C0C0_S2")
LABELS = ("mRNA-only baseline", "Ordinary probability stacking", "Complete AN-ReliefF + uncertainty-aware fusion", "Standard ReliefF fusion")
CLASSES = ("Luminal A", "Luminal B", "HER2-enriched", "Basal-like")
PROBS = tuple("probability::" + name for name in CLASSES)
METRICS = ("macro_f1", "accuracy", "balanced_accuracy", "macro_auc")
SUBMETRICS = ("precision", "recall", "f1")
COMPARISONS = ("R2_vs_R0", "R2_vs_R1", "R2_vs_R3")
COMPARISON_LABELS = ("Full multi-omics − mRNA-only", "Uncertainty-aware fusion − ordinary stacking", "AN-ReliefF − Standard ReliefF")
BASE_INDICES = (0, 1, 3)
N_BOOTSTRAP, SEED, TOL = 1000, 2026100901, 1e-12
HYPOTHESES = {'R2_vs_R3': 'H1', 'R2_vs_R0': 'H2', 'R2_vs_R1': 'H3'}

def require(condition, message):
    if not condition:
        raise RuntimeError('BOOTSTRAP_STOP: ' + message)

def build_auc_groups(y, probabilities):
    """Group exactly equal scores; ties receive half positive-negative pair weight."""
    groups = []
    for repeat in range(3):
        methods = []
        for method in range(4):
            classes = []
            for cls in range(4):
                score = probabilities[repeat, method, :, cls]
                order = np.argsort(score, kind="stable")
                sorted_score = score[order]
                starts = np.flatnonzero(np.r_[True, sorted_score[1:] != sorted_score[:-1]])
                classes.append((order, starts, (y[order] == cls).astype(float)))
            methods.append(classes)
        groups.append(methods)
    return groups

def weighted_auc(weights, group):
    order, starts, positive = group
    sorted_weights = weights[order]
    pos = np.add.reduceat(sorted_weights * positive, starts)
    neg = np.add.reduceat(sorted_weights * (1.0 - positive), starts)
    npos, nneg = pos.sum(), neg.sum()
    require(npos > 0 and nneg > 0, "AUC missing positive/negative samples")
    negatives_before = np.cumsum(neg) - neg
    return float(np.sum(pos * (negatives_before + 0.5 * neg)) / (npos * nneg))

def calculate(y, predicted, probabilities, weights, groups=None):
    """Replicate-weight equivalent metrics, individually per repeat and method."""
    groups = groups if groups is not None else build_auc_groups(y, probabilities)
    overall = np.empty((3, 4, 4), dtype=float)
    subtype = np.empty((3, 4, 4, 3), dtype=float)
    for repeat in range(3):
        for method in range(4):
            cm = np.bincount(4 * y + predicted[repeat, method], weights=weights, minlength=16).reshape(4, 4)
            tp = np.diag(cm)
            support, chosen = cm.sum(axis=1), cm.sum(axis=0)
            precision = np.divide(tp, chosen, out=np.zeros(4), where=chosen != 0)
            recall = np.divide(tp, support, out=np.zeros(4), where=support != 0)
            f1 = np.divide(2 * tp, support + chosen, out=np.zeros(4), where=(support + chosen) != 0)
            subtype[repeat, method] = np.column_stack((precision, recall, f1))
            overall[repeat, method] = (f1.mean(), tp.sum() / support.sum(), recall.mean(),
                                       np.mean([weighted_auc(weights, groups[repeat][method][c]) for c in range(4)]))
    return overall, subtype

def sample_multiplicities(y, n):
    rng = np.random.Generator(np.random.PCG64(SEED))
    by_class = [np.flatnonzero(y == cls) for cls in range(4)]
    counts = np.empty((n, len(y)), dtype=np.uint16)
    for iteration in range(n):
        drawn = np.concatenate([rng.choice(indices, size=len(indices), replace=True) for indices in by_class])
        counts[iteration] = np.bincount(drawn, minlength=len(y))
        require(int(counts[iteration].sum()) == 738, "sampling total")
        require(all(int(counts[iteration, ix].sum()) == len(ix) for ix in by_class), "sampling class total")
    return counts

def describe(values, observed):
    lo, hi = np.percentile(values, [2.5, 97.5], method="linear")
    return {"observed": float(observed), "bootstrap_mean": float(np.mean(values)), "bootstrap_median": float(np.median(values)), "ci_low": float(lo), "ci_high": float(hi), "n_bootstrap": len(values)}

def compute_bootstrap(y, predicted, probability):
    """Execute the fixed final analysis only after callers validate pairing.

    Returns original repeat-level and mean arrays plus summary rows. The caller
    must supply lexicographically ordered patients with the exact frozen labels,
    three repeat predictions and four aligned methods.
    """
    start = time.perf_counter()
    observed_repeat, observed_subtype = calculate(y, predicted, probability, np.ones(738))
    groups = build_auc_groups(y, probability)
    counts = sample_multiplicities(y, N_BOOTSTRAP)
    all_overall = np.empty((N_BOOTSTRAP, 3, 4, 4), float)
    all_subtype = np.empty((N_BOOTSTRAP, 3, 4, 4, 3), float)
    for iteration, weights in enumerate(counts):
        all_overall[iteration], all_subtype[iteration] = calculate(y, predicted, probability, weights, groups)
        if (iteration + 1) % 250 == 0:
            print(f"bootstrap {iteration + 1}/{N_BOOTSTRAP}; elapsed {time.perf_counter() - start:.2f}s", flush=True)
    mean_overall = all_overall.mean(axis=1)
    mean_subtype = all_subtype.mean(axis=1)
    delta_repeat = np.stack([all_overall[:, :, 2, 0] - all_overall[:, :, mi, 0] for mi in BASE_INDICES], axis=-1)
    delta_mean = delta_repeat.mean(axis=1)
    require(np.isfinite(all_overall).all() and np.isfinite(all_subtype).all(), "non-finite bootstrap metric")
    require(np.all((all_overall >= 0) & (all_overall <= 1)) and np.all((all_subtype >= 0) & (all_subtype <= 1)), "bootstrap metric range")
    require(np.allclose(delta_mean, mean_overall[:, 2, 0, None] - mean_overall[:, BASE_INDICES, 0], atol=TOL, rtol=0), "paired repeat-first aggregation")
    overall_rows, subtype_rows, delta_rows = [], [], []
    for mi, method in enumerate(METHODS):
        for ki, metric in enumerate(METRICS):
            overall_rows.append({"method": method, "method_label": LABELS[mi], "metric": metric,
                                 **describe(mean_overall[:, mi, ki], observed_repeat[:, mi, ki].mean())})
        for ci, subtype in enumerate(CLASSES):
            for ki, metric in enumerate(SUBMETRICS):
                subtype_rows.append({"method": method, "method_label": LABELS[mi], "subtype": subtype, "class_id": ci, "metric": metric,
                                     **describe(mean_subtype[:, mi, ci, ki], observed_subtype[:, mi, ci, ki].mean())})
    for di, (comparison, label, mi) in enumerate(zip(COMPARISONS, COMPARISON_LABELS, BASE_INDICES)):
        values = describe(delta_mean[:, di], (observed_repeat[:, 2, 0] - observed_repeat[:, mi, 0]).mean())
        delta_rows.append({"comparison": comparison, "comparison_label": label, "metric": "macro_f1", "unit": "proportion",
                           "full_method": METHODS[2], "comparator_method": METHODS[mi], **values,
                           "contains_zero": bool(values["ci_low"] <= 0 <= values["ci_high"])})
    iterations = np.arange(1, N_BOOTSTRAP + 1)
    return {
        'iteration': iterations,
        'multiplicity': counts,
        'observed_repeat': observed_repeat,
        'observed_subtype_repeat': observed_subtype,
        'overall_repeat': all_overall,
        'subtype_repeat': all_subtype,
        'overall_mean': mean_overall,
        'subtype_mean': mean_subtype,
        'paired_macro_f1_repeat': delta_repeat,
        'paired_macro_f1_mean': delta_mean,
        'overall_rows': overall_rows,
        'subtype_rows': subtype_rows,
        'paired_rows': delta_rows,
    }
