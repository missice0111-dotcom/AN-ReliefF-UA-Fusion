"""Fresh CPU XGB fits with exact-input reuse inside this main run only."""
from __future__ import annotations
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
import json
from pathlib import Path
from time import perf_counter
import numpy as np
from xgboost import XGBClassifier
from .common import *


def require(value, message):
    if not value:
        raise RuntimeError('STOP: ' + message)




def native_guard(model, parameters, seed):
    observed = model.get_params()
    require(all(observed[k] == v for k, v in parameters.items()), 'observed XGB parameters differ')
    require(observed['random_state'] == seed and np.array_equal(model.classes_, np.arange(4)), 'XGB seed/class order differs')
    config = json.loads(model.get_booster().save_config())
    learner = config['learner']; generic = learner['generic_param']
    require(generic['device'] == 'cpu' and int(generic['nthread']) == 4, 'XGB must be CPU4')
    require(learner['objective']['name'] == 'multi:softprob' and int(learner['learner_model_param']['num_class']) == 4, 'native XGB objective/classes differ')
    booster = learner['gradient_booster']
    require(booster['name'] == 'gbtree' and booster['gbtree_train_param']['tree_method'] == 'hist', 'native XGB booster/tree_method differs')
    require(int(model.get_booster().num_boosted_rounds()) == parameters['n_estimators'], 'XGB boosting rounds differ')
    return config


@dataclass
class FitBundle:
    receipt: dict
    path: Path
    key: str
    cache_hit: bool


class XGBRunner:
    def __init__(self, run, protocol):
        self.run = Path(run).resolve()
        self.protocol = protocol
        self.allowed = {object_hash(c['parameters']): c for c in protocol['xgboost_candidates']}
        require(len(self.allowed) == 20, 'exact20 XGB bank required')
        self.runtime = {}; self.guards = {}

    def fit(self, context, candidate):
        _, science = science_guard(self.run)
        params = dict(candidate['parameters'])
        require(object_hash(params) in self.allowed and self.allowed[object_hash(params)] == candidate, 'XGB candidate not in exact bank')
        require(all(params[k] == v for k, v in {'booster':'gbtree','objective':'multi:softprob','num_class':4,'tree_method':'hist','n_jobs':4}.items()), 'fixed CPU XGB definition differs')
        X = np.ascontiguousarray(context.X, dtype=np.float32)
        y = np.ascontiguousarray(context.y, dtype=np.int64)
        ids = list(context.train_ids); features = list(context.feature_ids)
        require(X.shape == (len(ids),len(features)) and np.isfinite(X).all() and set(y) == {0,1,2,3}, 'invalid XGB fit inputs')
        require(not set(ids) & set(context.validation_ids), 'fit/prediction patient overlap')
        identity = {'scientific_identity_hash':science,'omic':context.omic,'repeat':context.repeat,'outer_fold':context.outer_fold,'inner_fold':context.inner_fold,
                    'train_patient_ids':ids,'train_patient_ids_hash':lines_hash(ids),'feature_ids':features,'ordered_feature_hash':lines_hash(features),
                    'X_digest':array_digest(X),'y_digest':array_digest(y),'parameters':params,'paired_seeds':list(SEEDS),
                    'preprocessing_state_hash':context.metadata['preprocessing_state_hash'],'ANOVA1000_hash':context.metadata['anova_feature_hash']}
        key = object_hash(identity); phase = 'outer' if context.inner_fold is None else f'i{context.inner_fold}'
        folder = self.run / 'cache/xgb_models' / context.omic / f'r{context.repeat}_o{context.outer_fold}' / phase
        marker = folder / (key + '.fit.json'); hit = marker.exists(); began = perf_counter()
        if hit:
            rec = read_json(marker)
            require(rec['status'] == 'COMPLETE' and rec['identity'] == identity, 'current fit cache identity differs')
            for row in rec['seed_models']:
                require(Path(row['model_path']).resolve().is_relative_to(folder.resolve()) and file_hash(row['model_path']) == row['model_sha256'], 'current native XGB model changed')
        else:
            folder.mkdir(parents=True, exist_ok=True)
            def one(seed):
                model = XGBClassifier(**params, random_state=seed)
                start = perf_counter(); model.fit(X,y); seconds = perf_counter() - start
                native = native_guard(model,params,seed)
                path = folder / f'{key}_s{seed}.ubj'; model.save_model(path)
                return {'seed':seed,'model_path':str(path),'model_sha256':file_hash(path),'fit_seconds':seconds,'native_config':native,
                        'observed_parameters':{k:model.get_params()[k] for k in (*params,'random_state')},'model_classes':list(map(int,model.classes_))}
            with ThreadPoolExecutor(max_workers=3,thread_name_prefix='route_b_xgb') as pool:
                seeds = list(pool.map(one,SEEDS))
            require(array_digest(X) == identity['X_digest'] and array_digest(y) == identity['y_digest'], 'XGB fit mutated input')
            rec = {'status':'COMPLETE','identity':identity,'config_id':candidate['config_id'],'candidate_index':candidate['candidate_index'],
                   'seed_models':seeds,'fit_seconds':sum(x['fit_seconds'] for x in seeds),'ensemble_wall_seconds':perf_counter()-began,
                   'new_native_seed_models':3,'old_model_reuse':False,'early_stopping':False,'sample_weight':None,'outer_test_accessed':False}
            immutable_json(marker,rec)
        self.runtime[key] = {'omic':context.omic,'repeat':context.repeat,'outer_fold':context.outer_fold,'inner_fold':context.inner_fold,
                             'fit_receipt_path':str(marker),'fit_receipt_sha256':file_hash(marker),'fit_key':key,'fit_seconds':rec['fit_seconds'],
                             'ensemble_wall_seconds':rec['ensemble_wall_seconds'],'native_seed_models':3,'current_call_new_fits':0 if hit else 3,
                             'current_exact_input_cache_hit':hit,'old_model_reuse':False}
        return FitBundle(rec,marker,key,hit)

    def predict(self, fit, context, joint_lock=None):
        _, science = science_guard(self.run)
        require(fit.receipt['identity']['scientific_identity_hash'] == science and read_json(fit.path) == fit.receipt, 'fit science/receipt differs')
        require(context.Xv is not None, 'prediction transform not available')
        ids = list(context.validation_ids); X = np.ascontiguousarray(context.Xv,dtype=np.float32)
        require(X.shape == (len(ids),len(context.feature_ids)) and np.isfinite(X).all(), 'invalid XGB prediction inputs')
        require(fit.receipt['identity']['ordered_feature_hash'] == lines_hash(context.feature_ids) and fit.receipt['identity']['X_digest'] == array_digest(context.X), 'fit/selected input bridge differs')
        require(not set(ids) & set(fit.receipt['identity']['train_patient_ids']), 'prediction patient participated in XGB fit')
        lock_sha = None
        if context.inner_fold is None:
            require(joint_lock is not None, 'outer XGB prediction requires final meta lock')
            joint_lock = Path(joint_lock).resolve()
            require(joint_lock.is_relative_to(self.run), 'joint lock outside current run')
            lock = read_json(joint_lock)
            require(lock['status'] == 'META_PARAMETERS_AND_MODELS_LOCKED' and lock['scientific_identity_hash'] == science and not lock['outer_test_accessed'], 'invalid pre-predict joint lock')
            lock_sha = file_hash(joint_lock)
        identity = {'scientific_identity_hash':science,'fit_key':fit.key,'fit_receipt_sha256':file_hash(fit.path),'patient_ids':ids,
                    'patient_ids_hash':lines_hash(ids),'prediction_matrix_digest':array_digest(X),'ordered_feature_hash':lines_hash(context.feature_ids),
                    'phase':'outer' if context.inner_fold is None else 'inner','joint_lock_sha256':lock_sha}
        key = object_hash(identity); folder = fit.path.parent; marker = folder / (key + '.prediction.json'); hit = marker.exists()
        if hit:
            rec = read_json(marker); require(rec['identity'] == identity and rec['status'] == 'COMPLETE','current prediction cache identity differs')
            values=[]
            for row in rec['seed_probabilities']:
                require(file_hash(row['path']) == row['sha256'],'current seed probability changed'); values.append(np.load(row['path'],allow_pickle=False))
            p=np.load(rec['ensemble_path'],allow_pickle=False)
            require(file_hash(rec['ensemble_path']) == rec['ensemble_sha256'] and np.array_equal(p,np.mean(values,axis=0)), 'current probability mean/SHA differs')
        else:
            def one(row):
                model=XGBClassifier(**fit.receipt['identity']['parameters'],random_state=row['seed'])
                require(file_hash(row['model_path']) == row['model_sha256'],'saved native model changed before predict'); model.load_model(row['model_path'])
                start=perf_counter(); raw=np.asarray(model.predict_proba(X),dtype=np.float64); seconds=perf_counter()-start
                probability_guard(raw,len(ids),model.classes_)
                path=folder / f'{key}_s{row["seed"]}.npy';write_array(path,raw)
                return raw,{'seed':row['seed'],'path':str(path),'sha256':file_hash(path),'array_digest':array_digest(raw),'predict_seconds':seconds}
            with ThreadPoolExecutor(max_workers=3,thread_name_prefix='route_b_xgb_predict') as pool:
                values=list(pool.map(one,fit.receipt['seed_models']))
            p=np.mean([x[0] for x in values],axis=0);probability_guard(p,len(ids));path=folder/(key+'.npy');write_array(path,p)
            rec={'status':'COMPLETE','identity':identity,'seed_probabilities':[x[1] for x in values],'ensemble_path':str(path),'ensemble_sha256':file_hash(path),
                 'ensemble_digest':array_digest(p),'predict_seconds':sum(x[1]['predict_seconds'] for x in values),'fit_receipt_path':str(fit.path)}
            immutable_json(marker,rec)
        guard=probability_guard(p,len(ids));self.guards[key]={**guard,'prediction_key':key,'prediction_receipt_path':str(marker),'prediction_receipt_sha256':file_hash(marker),
                                                            'phase':identity['phase'],'fit_key':fit.key,'omic':context.omic,'repeat':context.repeat,'outer_fold':context.outer_fold,'inner_fold':context.inner_fold}
        return p,rec,marker,hit
