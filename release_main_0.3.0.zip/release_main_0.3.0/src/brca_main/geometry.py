from __future__ import annotations
import hashlib
import json
from pathlib import Path
from time import perf_counter
import numpy as np
from sklearn.metrics import pairwise_distances
from sklearn.preprocessing import StandardScaler
from . import numerical_core as historical
CLASS_NAMES=tuple(historical.CLASS_ORDER)
KS=(3,5,7,10)
MULTIPLIERS=(2,3,4)
TOP_MS=(50,100,200,400)

def lines_hash(values):
    return hashlib.sha256("".join(f"{v}\n" for v in values).encode()).hexdigest()


def config_id(k, c, r, top_m):
    return f"k{k:02d}_c{c if c is not None else 'NA'}_r{r if r is not None else 'NA'}_m{top_m:03d}"


def select_candidate(rows):
    valid = [row for row in rows if row["status"] == "COMPLETE"]
    if not valid:
        raise ValueError("No feasible fully evaluated inner candidate")
    maximum = max(float(row["pooled_inner_macro_f1"]) for row in valid)
    tied = [row for row in valid if abs(float(row["pooled_inner_macro_f1"]) - maximum) <= 1e-12]
    return min(tied, key=lambda row: (int(row["top_m"]), int(row["k"]),
               0 if row["c"] is None else int(row["c"]),
               0 if row["r"] is None else int(row["r"]), row["config_id"]))


def feasibility(labels, k, c, r, *, mechanism, scale_scope, legacy_clipping=False):
    """Worst eligible count over every anchor, including self exclusion."""
    y = np.asarray(labels, dtype=np.int64)
    counts = np.bincount(y, minlength=4)
    issues = []
    for target, n_class in enumerate(counts):
        available = int(n_class) - 1
        requirements = [("selected_neighbors", k)]
        if mechanism == "C2" and not legacy_clipping:
            requirements.append(("candidate_pool", c * k))
            if scale_scope == "class_specific":
                requirements.append(("local_scale", r * k))
        for component, required in requirements:
            if available < required:
                issues.append({"class": CLASS_NAMES[target], "component": component,
                               "available_n": available, "required_n": int(required)})
    if mechanism == "C2" and scale_scope == "global_nonself" and not legacy_clipping:
        if len(y) - 1 < r * k:
            issues.append({"class": "GLOBAL_NONSELF", "component": "local_scale",
                           "available_n": len(y) - 1, "required_n": r * k})
    return issues


class EuclideanContext:
    """Compute matrix and neighbor ordering once for an exact training context."""

    def __init__(self, X, labels, patient_ids, feature_ids, anova_scores):
        started = perf_counter()
        self.values = np.asarray(X, dtype=np.float64)
        self.labels = np.asarray(labels, dtype=np.int64)
        self.patient_ids = np.asarray(patient_ids, dtype=str)
        self.feature_ids = np.asarray(feature_ids, dtype=str)
        self.anova = np.asarray(anova_scores, dtype=np.float64)
        self.n = len(self.labels)
        assert self.values.shape == (self.n, len(self.feature_ids))
        assert len(self.feature_ids) == 1000 or self.n < 100  # small numerical QA only
        assert np.isfinite(self.values).all()
        assert np.array_equal(np.argsort(self.patient_ids, kind="stable"), np.arange(self.n))
        self.scaler = StandardScaler(with_mean=True, with_std=True)
        z = self.scaler.fit_transform(self.values)
        self.distances = pairwise_distances(z, metric="euclidean", n_jobs=1)
        np.fill_diagonal(self.distances, np.inf)
        self.distances.setflags(write=False)
        self.distance_seconds = perf_counter() - started
        started = perf_counter()
        indices = np.arange(self.n)
        self.global_sorted = np.argsort(self.distances, axis=1, kind="stable")
        self.class_sorted = []
        for target in range(4):
            members = indices[self.labels == target]
            rows = []
            for anchor in range(self.n):
                eligible = members[members != anchor]
                order = np.lexsort((eligible, self.distances[anchor, eligible]))
                rows.append(eligible[order])
            self.class_sorted.append(rows)
        self.sorted_seconds = perf_counter() - started
        self.prior = historical.miss_prior_matrix(self.labels)
        self._scales = {}
        self._scores = {}
        self.distance_compute_count = 1
        self.sorted_compute_count = 1
        self.cache_loaded = False
        self.cache_load_seconds = 0.0
        self.scoring_cache_hits = 0
        self.model_scale_mean = self.scaler.mean_.copy()
        self.model_scale_std = self.scaler.scale_.copy()

    def _scale(self, position, scope, target=None):
        key = (int(position), scope, target)
        if key not in self._scales:
            if scope == "global_nonself":
                ordered = self.global_sorted[:, min(position - 1, self.n - 2)]
                scale = self.distances[np.arange(self.n), ordered].copy()
            elif scope == "class_specific":
                scale = np.array([self.distances[a, row[position - 1]]
                                  for a, row in enumerate(self.class_sorted[target])])
            else:
                raise ValueError("Local scale scope requires an explicit frozen choice")
            good = scale[np.isfinite(scale) & (scale > 0)]
            fallback = float(np.median(good)) if len(good) else 1.0
            scale = np.where(np.isfinite(scale) & (scale > 0), scale, fallback)
            scale.setflags(write=False)
            self._scales[key] = scale
        return self._scales[key]

    def rank(self, *, k, c=None, r=None, mechanism, scale_scope, legacy_clipping=False, method="C2"):
        started = perf_counter()
        issues = feasibility(self.labels, k, c, r, mechanism=mechanism,
                             scale_scope=scale_scope, legacy_clipping=legacy_clipping)
        if issues:
            raise ValueError(f"INFEASIBLE_GEOMETRY: {issues}")
        if legacy_clipping:
            assert mechanism == "C2" and c == r == 3 and scale_scope == "global_nonself"
        neighbors = np.empty((self.n, 4, k), dtype=np.int64)
        for target in range(4):
            scale = self._scale(r * k, scale_scope, target if scale_scope == "class_specific" else None) if mechanism == "C2" else None
            for anchor in range(self.n):
                ordered = self.class_sorted[target][anchor]
                if mechanism == "C0":
                    selected = ordered[:k]
                else:
                    pool = ordered[:c * k]
                    denominator = np.maximum(scale[anchor] * scale[pool], np.finfo(float).eps)
                    affinity = np.exp(-np.square(self.distances[anchor, pool]) / denominator)
                    affinity[~np.isfinite(affinity)] = 0.0
                    order = np.lexsort((pool, self.distances[anchor, pool], -affinity))
                    selected = pool[order[:k]]
                neighbors[anchor, target] = selected
        # Identical WHO/k imply identical frozen updates. Cache the score vector.
        score_key = (k, hashlib.sha256(neighbors.tobytes()).hexdigest())
        if score_key not in self._scores:
            coefficients = np.zeros((self.n, self.n), dtype=np.float64)
            for anchor in range(self.n):
                own = int(self.labels[anchor])
                for target in range(4):
                    mass = -1.0 if target == own else self.prior[anchor, target]
                    coefficients[anchor, neighbors[anchor, target]] += mass / (self.n * k)
            self._scores[score_key] = historical._relief_scores(self.values, coefficients)
        else:
            self.scoring_cache_hits += 1
        scores = self._scores[score_key]
        ranking = historical._ranking(method, k, self.feature_ids, self.anova, scores, {
            "distance_space": "training_z_standardized_euclidean", "local_scale_scope": scale_scope,
            "k": k, "c": c, "r": r, "legacy_candidate_clipping": legacy_clipping,
            "selected_neighbor_weight": "1/k", "anchor_mass": "1/n"})
        return ranking, neighbors, perf_counter() - started


def _array_digest(values):
    values = np.asarray(values)
    digest = hashlib.sha256()
    digest.update(str(values.dtype).encode())
    digest.update(str(values.shape).encode())
    digest.update(np.ascontiguousarray(values).tobytes())
    return digest.hexdigest()


def _file_digest(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _context_identity(values, labels, patient_ids, feature_ids, anova, cache_key, scientific_identity_hash):
    return {
        "schema_version": 1, "cache_key": cache_key,
        "scientific_identity_hash": scientific_identity_hash,
        "geometry_core_sha256": _file_digest(__file__),
        "values_digest": _array_digest(np.asarray(values, dtype=np.float64)),
        "labels_digest": _array_digest(np.asarray(labels, dtype=np.int64)),
        "training_ids_hash": lines_hash(np.asarray(patient_ids, dtype=str)),
        "feature_ids_hash": lines_hash(np.asarray(feature_ids, dtype=str)),
        "anova_digest": _array_digest(np.asarray(anova, dtype=np.float64)),
        "n_patients": len(labels), "n_features": len(feature_ids),
        "metric": "training_z_standardized_euclidean", "self_distance": "Inf",
    }


def _validated_cache_receipt(folder, identity):
    marker = folder / "distance_complete.json"
    if not marker.exists():
        return None
    receipt = json.loads(marker.read_text(encoding="utf-8"))
    if receipt.get("status") != "SHARED_DISTANCE_CONTEXT_COMPLETE" or receipt.get("identity") != identity:
        raise ValueError("Shared-distance cache identity/source mismatch")
    required = {"distances.npy", "global_sorted.npy", "class_sorted_flat.npy", "class_sorted_offsets.npy",
                "scaler_mean.npy", "scaler_scale.npy", "scaler_var.npy"}
    if set(receipt.get("array_sha256", {})) != required:
        raise ValueError("Shared-distance cache array receipt is incomplete")
    for name, expected in receipt["array_sha256"].items():
        path = folder / name
        if not path.is_file() or _file_digest(path) != expected:
            raise ValueError(f"Shared-distance cache SHA256 mismatch: {name}")
    if receipt.get("distance_compute_count") != 1 or receipt.get("sorted_compute_count") != 1:
        raise ValueError("Shared-distance cache once-only counters differ")
    return receipt


def save_context(context, folder, cache_key, scientific_identity_hash):
    """Persist only geometry; bind all training inputs without duplicating X."""
    folder = Path(folder)
    identity = _context_identity(context.values, context.labels, context.patient_ids,
                                 context.feature_ids, context.anova, cache_key, scientific_identity_hash)
    folder.mkdir(parents=True, exist_ok=True)
    existing = _validated_cache_receipt(folder, identity)
    if existing is not None:
        return existing
    flat = np.concatenate([row for target in context.class_sorted for row in target]).astype(np.int64, copy=False)
    offsets = np.zeros((4, context.n + 1), dtype=np.int64)
    cursor = 0
    for target, rows in enumerate(context.class_sorted):
        offsets[target, 0] = cursor
        for anchor, row in enumerate(rows):
            cursor += len(row)
            offsets[target, anchor + 1] = cursor
    arrays = {"distances.npy": context.distances, "global_sorted.npy": context.global_sorted,
              "class_sorted_flat.npy": flat, "class_sorted_offsets.npy": offsets,
              "scaler_mean.npy": context.scaler.mean_, "scaler_scale.npy": context.scaler.scale_,
              "scaler_var.npy": context.scaler.var_}
    hashes = {}
    for name, values in arrays.items():
        destination = folder / name
        temporary = folder / (name + ".partial")
        with temporary.open("wb") as handle:
            np.save(handle, values, allow_pickle=False)
        temporary.replace(destination)
        hashes[name] = _file_digest(destination)
    receipt = {"status": "SHARED_DISTANCE_CONTEXT_COMPLETE", "identity": identity, "array_sha256": hashes,
               "distance_seconds": float(context.distance_seconds), "sorted_seconds": float(context.sorted_seconds),
               "distance_compute_count": int(context.distance_compute_count),
               "sorted_compute_count": int(context.sorted_compute_count),
               "scaler_n_samples_seen": int(context.scaler.n_samples_seen_),
               "scaler_n_features_in": int(context.scaler.n_features_in_),
               "values_persisted": False}
    temporary = folder / "distance_complete.json.partial"
    temporary.write_text(json.dumps(receipt, indent=2, sort_keys=True, allow_nan=False) + "\n", encoding="utf-8")
    temporary.replace(folder / "distance_complete.json")
    return receipt


def load_context(X, labels, patient_ids, feature_ids, anova, folder, cache_key, scientific_identity_hash):
    """Restore verified geometry without fitting a scaler or recomputing D."""
    started = perf_counter()
    folder = Path(folder)
    if not (folder / "distance_complete.json").exists():
        return None
    values = np.asarray(X, dtype=np.float64)
    labels = np.asarray(labels, dtype=np.int64)
    patients = np.asarray(patient_ids, dtype=str)
    features = np.asarray(feature_ids, dtype=str)
    scores = np.asarray(anova, dtype=np.float64)
    identity = _context_identity(values, labels, patients, features, scores, cache_key, scientific_identity_hash)
    receipt = _validated_cache_receipt(folder, identity)
    arrays = {name: np.load(folder / name, allow_pickle=False) for name in receipt["array_sha256"]}
    n, p = len(labels), len(features)
    distances, global_sorted = arrays["distances.npy"], arrays["global_sorted.npy"]
    flat, offsets = arrays["class_sorted_flat.npy"], arrays["class_sorted_offsets.npy"]
    if (values.shape != (n, p) or not np.isfinite(values).all()
            or not np.array_equal(np.argsort(patients, kind="stable"), np.arange(n))
            or distances.shape != (n, n) or distances.dtype != np.float64
            or not np.isposinf(np.diag(distances)).all()
            or global_sorted.shape != (n, n) or global_sorted.dtype.kind not in "iu"
            or flat.ndim != 1 or flat.dtype != np.int64 or offsets.shape != (4, n + 1)
            or offsets.dtype != np.int64 or offsets[0, 0] != 0 or offsets[-1, -1] != len(flat)
            or np.any(np.diff(offsets, axis=1) < 0)
            or not np.array_equal(offsets[1:, 0], offsets[:-1, -1])
            or np.any(flat < 0) or np.any(flat >= n)
            or receipt["scaler_n_samples_seen"] != n or receipt["scaler_n_features_in"] != p):
        raise ValueError("Shared-distance cache array shape/type contract differs")
    for name in ("scaler_mean.npy", "scaler_scale.npy", "scaler_var.npy"):
        if arrays[name].shape != (p,) or not np.isfinite(arrays[name]).all():
            raise ValueError("Shared-distance cache scaler state differs")
    class_sorted = []
    for target in range(4):
        rows = []
        for anchor in range(n):
            row = flat[offsets[target, anchor]:offsets[target, anchor + 1]]
            expected = np.count_nonzero(labels == target) - int(labels[anchor] == target)
            if len(row) != expected or np.any(row == anchor) or np.any(labels[row] != target):
                raise ValueError("Shared-distance cache eligible class ordering differs")
            row.setflags(write=False)
            rows.append(row)
        class_sorted.append(rows)
    context = object.__new__(EuclideanContext)
    context.values, context.labels, context.patient_ids = values, labels, patients
    context.feature_ids, context.anova, context.n = features, scores, n
    context.scaler = StandardScaler(with_mean=True, with_std=True)
    context.scaler.mean_, context.scaler.scale_, context.scaler.var_ = (arrays[name] for name in
        ("scaler_mean.npy", "scaler_scale.npy", "scaler_var.npy"))
    context.scaler.n_samples_seen_, context.scaler.n_features_in_ = n, p
    distances.setflags(write=False); global_sorted.setflags(write=False)
    context.distances, context.global_sorted, context.class_sorted = distances, global_sorted, class_sorted
    context.distance_seconds, context.sorted_seconds = receipt["distance_seconds"], receipt["sorted_seconds"]
    context.distance_compute_count = context.sorted_compute_count = 1
    context.cache_loaded, context.cache_load_seconds = True, perf_counter() - started
    context.prior = historical.miss_prior_matrix(labels)
    context._scales, context._scores, context.scoring_cache_hits = {}, {}, 0
    context.model_scale_mean, context.model_scale_std = context.scaler.mean_.copy(), context.scaler.scale_.copy()
    return context
