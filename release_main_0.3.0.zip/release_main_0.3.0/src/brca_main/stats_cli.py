"""User-input adapter for the actual final main bootstrap analysis.

No predictions are bundled. No model code is imported by this module. The
bootstrap action calculates statistics only after all scientific input checks.
"""
from __future__ import annotations

import argparse
from pathlib import Path
import numpy as np
import pandas as pd

from . import bootstrap as numerical


REQUIRED_COLUMNS = (
    'variant', 'repeat', 'outer_fold', 'patient_id', 'true_label',
    'predicted_label', *numerical.PROBS,
)


def read_predictions(path):
    """Read original full-precision columns without renormalizing probabilities."""
    numerical.require(Path(path).is_file(), 'prediction input file does not exist')
    return pd.read_csv(path, sep='\t', float_precision='round_trip',
                       keep_default_na=False, dtype={'patient_id': str})


def prediction_files(predictions=None, run=None):
    numerical.require((predictions is None) != (run is None),
                      'provide exactly one prediction file or run/parts directory')
    if predictions is not None:
        return [Path(predictions)], None
    root = Path(run)
    parts = root/'parts' if (root/'parts').is_dir() else root
    files = [parts/f'r{repeat}_o{fold}'/'predictions.tsv'
             for repeat in (1, 2, 3) for fold in range(1, 6)]
    numerical.require(all(path.is_file() for path in files),
                      'run/parts must contain all 15 prediction tables')
    return files, [(r, o) for r in (1, 2, 3) for o in range(1, 6)]


def validate_frame(frame, cohort, splits):
    """Validate frozen patient identities, labels, folds and full pairing.

    This guard performs no metric computation or resampling. It preserves the
    actual script's lexicographic patient order and probability checks while
    replacing historical private seals with the released scientific roster.
    """
    numerical.require(set(REQUIRED_COLUMNS).issubset(frame.columns),
                      'required prediction columns are missing')
    numerical.require(len(frame) == 8856, 'prediction rows must equal 8856')
    numerical.require(set(frame.variant) == set(numerical.METHODS),
                      'four final methods are required')
    numerical.require(not frame.duplicated(['variant', 'repeat', 'patient_id']).any(),
                      'duplicate method-repeat-patient records')
    for name, allowed in (('repeat', (1, 2, 3)), ('outer_fold', (1, 2, 3, 4, 5)),
                          ('true_label', (0, 1, 2, 3)), ('predicted_label', (0, 1, 2, 3))):
        values = pd.to_numeric(frame[name], errors='coerce').to_numpy(float)
        numerical.require(np.isfinite(values).all() and np.isin(values, allowed).all(),
                          'invalid integer prediction label or repeat/fold index')
        frame[name] = values.astype(np.int64)
    p = frame[list(numerical.PROBS)].to_numpy(float)
    numerical.require(p.shape == (8856, 4) and np.isfinite(p).all()
                      and ((p >= 0) & (p <= 1)).all(), 'probability shape/finite/range')
    numerical.require(float(np.max(np.abs(p.sum(axis=1)-1))) <= 1e-6,
                      'frozen probability normalization tolerance exceeded')
    numerical.require(np.array_equal(p.argmax(axis=1), frame.predicted_label.to_numpy(int)),
                      'probability order/argmax differs')
    patients = sorted(frame.patient_id.unique())
    numerical.require(len(patients) == 738 and set(patients) == set(cohort.patient_id),
                      'prediction patient set differs from frozen cohort')
    labels = {patient: numerical.CLASSES.index(subtype)
              for patient, subtype in zip(cohort.patient_id, cohort.subtype)}
    y = np.asarray([labels[patient] for patient in patients], dtype=np.int64)
    numerical.require(np.array_equal(np.bincount(y, minlength=4), [415, 145, 46, 132]),
                      'frozen class composition differs')
    expected = {}
    for fold in splits['folds']:
        for patient in fold['test_patient_ids']:
            expected[int(fold['repeat']), patient] = int(fold['outer_fold'])
    probability = np.empty((3, 4, 738, 4), float)
    predicted = np.empty((3, 4, 738), np.int64)
    folds = np.empty((3, 738), np.int64)
    for ri, repeat in enumerate((1, 2, 3)):
        baseline_fold = None
        for mi, method in enumerate(numerical.METHODS):
            small = frame[(frame.variant == method) & (frame.repeat == repeat)]
            numerical.require(len(small) == small.patient_id.nunique() == 738
                              and set(small.patient_id) == set(patients),
                              'complete paired patient set is required in each method and repeat')
            small = small.set_index('patient_id').loc[patients]
            numerical.require(np.array_equal(small.true_label.to_numpy(int), y),
                              'paired true labels differ from frozen cohort')
            current_fold = small.outer_fold.to_numpy(int)
            frozen_fold = np.asarray([expected[repeat, patient] for patient in patients], dtype=np.int64)
            numerical.require(np.array_equal(current_fold, frozen_fold),
                              'outer predictions differ from frozen test partitions')
            if baseline_fold is None:
                baseline_fold = current_fold
                folds[ri] = current_fold
            numerical.require(np.array_equal(current_fold, baseline_fold), 'paired fold assignments differ')
            probability[ri, mi] = small[list(numerical.PROBS)].to_numpy(float)
            predicted[ri, mi] = small.predicted_label.to_numpy(int)
    return patients, y, predicted, probability, folds


def load_checked_inputs(args):
    from .common import file_hash
    from .input_contract import validate_cohort_splits

    cohort, splits = validate_cohort_splits(args.cohort, args.splits)
    paths, contexts = prediction_files(args.predictions, args.run)
    protected = [*paths, Path(args.cohort), Path(args.splits)]
    hashes = [file_hash(path) for path in protected]
    frames = []
    for index, path in enumerate(paths):
        frame = read_predictions(path)
        numerical.require(set(REQUIRED_COLUMNS).issubset(frame.columns),
                          'required prediction columns are missing')
        if contexts is not None:
            repeat, fold = contexts[index]
            numerical.require(frame.repeat.eq(repeat).all() and frame.outer_fold.eq(fold).all(),
                              'part data context differs from its directory')
        frames.append(frame)
    frame = pd.concat(frames, ignore_index=True)
    arrays = validate_frame(frame, cohort, splits)
    numerical.require(hashes == [file_hash(path) for path in protected],
                      'prediction or scientific input changed while reading')
    return arrays, protected, hashes


def bootstrap(args):
    """Explicitly execute the fixed statistical analysis on user-owned files."""
    from .cli import fresh_output
    from .common import file_hash, write_json, write_tsv

    arrays, inputs, hashes = load_checked_inputs(args)
    patients, y, predicted, probability, folds = arrays
    protected = [*inputs, Path(__file__).resolve().parent]
    if args.run is not None:
        protected.append(Path(args.run))
    output = fresh_output(args.output, protected)
    result = numerical.compute_bootstrap(y, predicted, probability)
    numerical.require(hashes == [file_hash(path) for path in inputs],
                      'prediction or scientific input changed during computation')
    metrics_dir = output/'metrics'
    data_dir = output/'data'
    metrics_dir.mkdir(exist_ok=True)
    data_dir.mkdir(exist_ok=True)
    write_tsv(metrics_dir/'overall_bootstrap_summary.tsv', result['overall_rows'])
    write_tsv(metrics_dir/'subtype_bootstrap_summary.tsv', result['subtype_rows'])
    paired_rows = [dict(row, hypothesis=numerical.HYPOTHESES[row['comparison']])
                   for row in result['paired_rows']]
    write_tsv(metrics_dir/'paired_macro_f1_summary.tsv', paired_rows)
    write_tsv(metrics_dir/'bootstrap_paired_deltas.tsv', pd.DataFrame({
        'iteration': result['iteration'],
        **{key: result['paired_macro_f1_mean'][:, i]
           for i, key in enumerate(numerical.COMPARISONS)},
    }))
    np.savez_compressed(data_dir/'bootstrap_patient_multiplicities.npz',
        iteration=result['iteration'], patient_id=np.asarray(patients), y=y,
        multiplicity=result['multiplicity'], seed=np.array(numerical.SEED, dtype=np.int64),
        classes=np.array(numerical.CLASSES))
    np.savez_compressed(metrics_dir/'bootstrap_metrics.npz',
        iteration=result['iteration'], overall_repeat=result['overall_repeat'],
        subtype_repeat=result['subtype_repeat'], overall_mean=result['overall_mean'],
        subtype_mean=result['subtype_mean'], paired_macro_f1_repeat=result['paired_macro_f1_repeat'],
        paired_macro_f1_mean=result['paired_macro_f1_mean'], methods=np.array(numerical.METHODS),
        classes=np.array(numerical.CLASSES), metrics=np.array(numerical.METRICS),
        subtype_metrics=np.array(numerical.SUBMETRICS), comparisons=np.array(numerical.COMPARISONS))
    files = [path for path in sorted(output.rglob('*')) if path.is_file()]
    write_json(output/'statistical_analysis_receipt.json', {
        'status': 'COMPLETE', 'n_patient_clusters': 738, 'n_bootstrap': numerical.N_BOOTSTRAP,
        'seed': numerical.SEED, 'rng': 'numpy.random.Generator(PCG64)',
        'class_counts': np.bincount(y, minlength=4).tolist(),
        'shared_multiplicity_across_methods_and_repeats': True,
        'repeat_aggregation': 'repeat-first arithmetic mean',
        'confidence_interval': '2.5/97.5 percentile; numpy method linear',
        'hypothesis_mapping': {'H1': 'R2_vs_R3', 'H2': 'R2_vs_R0', 'H3': 'R2_vs_R1'},
        'probabilities_renormalized': False, 'models_fitted': 0, 'model_predictions_executed': 0,
        'significance_tests_performed': 0,
        'input_sources': [{'source_file': path.name, 'sha256': digest}
                          for path, digest in zip(inputs, hashes)],
        'output_sha256': {path.relative_to(output).as_posix(): file_hash(path) for path in files},
        'interpretation': 'Conditional on the fixed OOF prediction vectors and observed subtype composition; not the uncertainty of retraining or parameter selection.',
    })
    print('Completed the fixed paired patient bootstrap on user-supplied predictions; no models were fit or predicted.')


def add_parser(commands):
    parser = commands.add_parser('bootstrap', help='Run the actual final paired patient bootstrap on user-provided full-precision OOF predictions; no model operations.')
    inputs = parser.add_mutually_exclusive_group(required=True)
    inputs.add_argument('--predictions', type=Path, help='One merged full-precision TSV or TSV.GZ with all 8856 outer OOF rows.')
    inputs.add_argument('--run', type=Path, help='Completed user run or its parts directory containing 15 prediction TSV files.')
    for name in ('cohort', 'splits', 'output'):
        parser.add_argument('--'+name, type=Path, required=True)
    parser.set_defaults(action=bootstrap)
    return parser


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    add_parser(commands)
    args = parser.parse_args(argv)
    args.action(args)


if __name__ == '__main__':
    main()
