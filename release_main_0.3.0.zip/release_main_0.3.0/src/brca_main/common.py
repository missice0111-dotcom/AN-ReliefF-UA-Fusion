from __future__ import annotations
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd
CLASS_NAMES=('Luminal A','Luminal B','HER2-enriched','Basal-like')
SEEDS=(2026092401,2026092402,2026092403)
VARIANTS=('R0_MRNA_ONLY','R1_MULTIOMICS_S1','R2_ROUTE_B_S2','R3_C0C0_S2')
METHODS=VARIANTS
OUTER_SEEDS=(2026100821,2026100822,2026100823)
SELECTION_SEQUENCE=('XGB_00_C0_GEOMETRY','XGB_00_C2_GEOMETRY','SELECTED_C0_FEATURES_20_XGB','SHARE_XGB_WITH_C0_AND_C2','STRICT_BASE_OOF','S1_S2_INNER_META_SELECTION','ALL_PARAMETERS_AND_META_MODELS_LOCK','OUTER_REFIT_AND_PREDICT','ALL_FOUR_PREDICTIONS_LOCK','OUTER_LABEL_EVALUATION')
SUBSETS={'NONE':(), 'U01':('maxP',), 'U02':('margin',), 'U03':('entropy',), 'U04':('maxP','margin'), 'U05':('maxP','entropy'), 'U06':('margin','entropy'), 'U07':('maxP','margin','entropy')}
BASE_FEATURE_NAMES=tuple(f'{omic}::{name}' for omic in ('RNA','Methyl') for name in CLASS_NAMES)

def file_hash(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for b in iter(lambda:stream.read(1024*1024),b''):h.update(b)
    return h.hexdigest()


def object_hash(value):
    return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode('utf-8')).hexdigest()


def array_digest(value):
    a=np.ascontiguousarray(value);h=hashlib.sha256();h.update(str(a.dtype).encode('ascii'));h.update(str(a.shape).encode('ascii'));h.update(a.tobytes());return h.hexdigest()


def lines_hash(values):return hashlib.sha256(''.join(str(x)+'\n' for x in values).encode('utf-8')).hexdigest()


def read_json(path):return json.loads(Path(path).read_text(encoding='utf-8'))


def read_tsv(path):return pd.read_csv(path,sep='\t',float_precision='round_trip')


def write_json(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);temp=path.with_name(path.name+'.partial');temp.write_text(json.dumps(value,ensure_ascii=False,sort_keys=True,indent=2,allow_nan=False)+'\n',encoding='utf-8');temp.replace(path)


def immutable_json(path,value):
    if Path(path).exists():
        if read_json(path)!=value:raise RuntimeError('STOP: immutable JSON differs: '+str(path))
    else:write_json(path,value)


def write_tsv(path,rows,columns=None):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);f=rows if isinstance(rows,pd.DataFrame) else pd.DataFrame(rows,columns=columns);temp=path.with_name(path.name+'.partial');f.to_csv(temp,sep='\t',index=False,float_format='%.17g',lineterminator='\n');temp.replace(path)


def write_array(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);temp=path.with_name(path.name+'.partial')
    with temp.open('wb') as f:np.save(f,value,allow_pickle=False)
    temp.replace(path)


def probability_guard(p,expected_n,observed_classes=(0,1,2,3),tolerance=1e-6):
    a=np.asarray(p,dtype=np.float64)
    if a.shape!=(expected_n,4) or not np.array_equal(observed_classes,np.arange(4)) or not np.isfinite(a).all() or not ((a>=0).all() and (a<=1).all()) or np.max(np.abs(a.sum(1)-1))>tolerance:raise RuntimeError('STOP: probability shape/order/finite/bounds/sum failure')
    return {'n_rows':expected_n,'class_order':','.join(CLASS_NAMES),'model_class_order':'0,1,2,3','finite':True,'bounds_valid':True,'max_sum_deviation':float(np.max(np.abs(a.sum(1)-1))),'sum_tolerance':tolerance,'status':'PASS'}


def metric_values(y,p):
    from sklearn.metrics import f1_score,accuracy_score,balanced_accuracy_score
    pred=np.argmax(p,axis=1)
    return {'macro_f1':float(f1_score(y,pred,labels=np.arange(4),average='macro',zero_division=0)),'accuracy':float(accuracy_score(y,pred)),'balanced_accuracy':float(balanced_accuracy_score(y,pred))}


def meta_features(rna,methyl,subset_id):
    rna=np.asarray(rna,dtype=np.float64);methyl=np.asarray(methyl,dtype=np.float64)
    if rna.shape!=methyl.shape:raise RuntimeError('STOP: aligned base probability shapes differ')
    probability_guard(rna,len(rna));probability_guard(methyl,len(methyl));s1=np.column_stack((rna,methyl));u=uncertainty_features(rna)
    positions=[('maxP','margin','entropy').index(x) for x in SUBSETS[subset_id]]
    return (np.column_stack((s1,u[:,positions])) if positions else s1),BASE_FEATURE_NAMES+tuple('RNA_'+x for x in SUBSETS[subset_id])


def candidates(variant):
    if variant not in VARIANTS[1:]:raise ValueError('No meta bank for RNA-only')
    subset_ids=('NONE',) if variant==VARIANTS[1] else tuple(k for k in SUBSETS if k!='NONE')
    rows=[]
    for subset in subset_ids:
        for c in (.01,.1,1.,10.,100.):
            for scaling in (False,True):
                rows.append({'config_id':f'{subset}_C{c:g}_S{int(scaling)}','subset_id':subset,'uncertainty_features_json':json.dumps(SUBSETS[subset]),'n_uncertainty_features':len(SUBSETS[subset]),'C':c,'meta_scaling':scaling,'meta_dim':8+len(SUBSETS[subset])})
    return rows


def choose_candidate(rows,variant,tolerance=1e-12):
    eligible=[r for r in rows if r['status']=='COMPLETE'];best=max(r['pooled_meta_macro_f1'] for r in eligible);ties=[r for r in eligible if best-r['pooled_meta_macro_f1']<=tolerance]
    if variant in VARIANTS[2:]:return min(ties,key=lambda r:(int(r['n_uncertainty_features']),float(r['C']),bool(r['meta_scaling']),r['subset_id']))
    return min(ties,key=lambda r:(float(r['C']),bool(r['meta_scaling']),r['config_id']))


def support(deltas):
    return bool(np.mean(deltas)>0 and sum(x>0 for x in deltas)>=2)

from .numerical_core import uncertainty_features as _accepted_uncertainty

def uncertainty_features(p):
    probability_guard(p,len(p))
    return _accepted_uncertainty(p)


def require(condition, message):
    if not condition: raise RuntimeError('STOP: '+message)

def science_guard(run):
    """Bind local scientific config, supplied inputs/splits and package bytes."""
    run=Path(run)
    identity=read_json(run/'audit/scientific_run_identity.json')
    require(identity['status']=='SCIENTIFIC_INPUTS_FROZEN_BEFORE_FITS','science not frozen')
    for row in identity['file_integrity']:
        require(file_hash(Path(__file__).parent/row['source_file'])==row['sha256'],'package source changed')
    for relative,key in (('protocol/main_scientific_config.json','protocol_sha256'),('splits/frozen_splits.json','split_sha256'),('inputs/cohort.tsv','cohort_sha256')):
        require(file_hash(run/relative)==identity[key],'scientific input changed: '+relative)
    require(scientific_environment()==identity['environment_versions'],'scientific package versions changed')
    return identity,object_hash(identity)

def validate_identity(run):
    return science_guard(run)[0]

def scientific_environment():
    from importlib.metadata import version
    packages=('numpy','pandas','scipy','scikit-learn','xgboost','threadpoolctl')
    observed={name:version(name) for name in packages}
    require(all(observed[k]==v for k,v in {'numpy':'1.26.4','scikit-learn':'1.5.1','xgboost':'2.1.1'}.items()),'frozen numerical/classifier/meta versions differ; use the documented independent environment')
    return observed
