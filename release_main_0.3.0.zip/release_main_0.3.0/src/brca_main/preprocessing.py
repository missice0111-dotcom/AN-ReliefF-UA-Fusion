from __future__ import annotations
from collections import Counter
import csv
from dataclasses import dataclass
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
from typing import Callable, Iterable, Sequence
import numpy as np
import pandas as pd
CLASS_ORDER = ("Luminal A", "Luminal B", "HER2-enriched", "Basal-like")
COUNTS = {"Luminal A": 415, "Luminal B": 145, "HER2-enriched": 46, "Basal-like": 132}
NA_TOKENS = {"", "na", "n/a", "nan", "null", "none", ".", "?"}
EXPECTED_FEATURES = {"mrna": 60660, "methyl": 396065}
FEATURE_FILE_HASHES = {
    "mrna": "9c09c081adf97fc5686d5ee273e4c47b0e7fff6f4dab091ecf190c894ad7c959",
    "methyl": "f5114876d0c4e3f25ed2e12e0a082600966a5ad0a8c589cd88e9057e52b97f72",
}
PREPROCESSING_PROVENANCE = {
    "original_source_available": False,
    "original_source_expected_sha256": "2a530e9f15ee701722f1d83d44f0976e1a9e12b5451de0883feba3d3df429c44",
    "operation_source": "config/scientific_config.json#preprocessing",
    "arithmetic_adapter_source": "src/brca_main/preprocessing.py",
    "historical_raw_dtype": "<f4",
    "state_dtype": "float32",
    "statistics_dtype": "float64",
    "output_dtype": "float32",
    "source_byte_parity_claimed": False,
    "acceptance": "the accepted preprocessing implementation actually used by the final main run; earlier unavailable-source reconstruction is documented",
}

def sha256_file(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def sha256_lines(values: Iterable[str]) -> str:
    digest = hashlib.sha256()
    for value in values:
        digest.update(str(value).encode("utf-8"))
        digest.update(b"\n")
    return digest.hexdigest()


def write_json(path: str | Path, value: object) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    partial = path.with_name(path.name + ".partial")
    partial.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True,
                                  allow_nan=False) + "\n", encoding="utf-8", newline="\n")
    os.replace(partial, path)


def _validate_pam50(path: Path, cohort: pd.DataFrame) -> pd.DataFrame:
    frame = pd.read_excel(path, sheet_name="TCGASubtype.20170308", dtype=str)
    if not {"sampleID", "Subtype_mRNA"}.issubset(frame.columns):
        raise RuntimeError("STOP: PAM50 workbook schema mismatch")
    mapping = {"luma": "Luminal A", "luminala": "Luminal A", "lumb": "Luminal B",
               "luminalb": "Luminal B", "her2": "HER2-enriched", "her2enriched": "HER2-enriched",
               "basal": "Basal-like", "basallike": "Basal-like", "normal": "Normal-like",
               "normallike": "Normal-like"}
    grouped: dict[str, set[str]] = {}
    for raw_id, raw_label in frame[["sampleID", "Subtype_mRNA"]].itertuples(index=False, name=None):
        match = re.fullmatch(r"(TCGA-[A-Z0-9]{2}-[A-Z0-9]{4})(?:-01[A-Z]?(?:-[A-Z0-9]+)*)?", str(raw_id))
        if not match:
            continue
        key = re.sub("[^a-z0-9]", "", str(raw_label).lower()).removeprefix("brca")
        if key in mapping:
            grouped.setdefault(match.group(1), set()).add(mapping[key])
    rows = []
    for patient, label in cohort[["patient_id", "subtype"]].itertuples(index=False, name=None):
        if grouped.get(patient) != {label}:
            raise RuntimeError(f"STOP: authoritative PAM50 mismatch for {patient}")
        rows.append({"patient_id": patient, "frozen_label": label, "pam50_label": label,
                     "authoritative_primary_label_matches": True})
    return pd.DataFrame(rows)


def _numeric_block(frame: pd.DataFrame, omics: str) -> np.ndarray:
    # Historical tcga_prepare.matrix.numeric_block: parse decimal strings as
    # float64 before validation and the sole raw-input float32 rounding.
    tokens = frame.astype(str).apply(lambda column: column.str.strip())
    missing = tokens.apply(lambda column: column.str.lower().isin(NA_TOKENS))
    numeric = tokens.mask(missing).apply(pd.to_numeric, errors="coerce")
    invalid = numeric.isna() & ~missing
    if invalid.to_numpy().any():
        row, col = np.argwhere(invalid.to_numpy())[0]
        raise ValueError(f"Invalid {omics} numeric token at data row {frame.index[row]}: {tokens.iat[row, col]!r}")
    values64 = numeric.to_numpy(dtype=np.float64)
    observed = values64[~np.isnan(values64)]
    if np.isinf(observed).any() or (observed.size and np.max(np.abs(observed)) > np.finfo(np.float32).max):
        raise ValueError(f"Invalid {omics} numeric range")
    if observed.size and ((observed < 0).any() or (omics == "methyl" and (observed > 1).any())):
        raise ValueError(f"Invalid {omics} domain")
    return values64.astype("<f4")


def _materialize_omic(source: Path, cohort: pd.DataFrame, omics: str, out: Path,
                      logger: Callable[[str], None]) -> dict:
    sep = "," if omics == "mrna" else "\t"
    opener = gzip.open if source.suffix == ".gz" else open
    with opener(source, "rt", encoding="utf-8-sig", newline="") as handle:
        header = next(csv.reader(handle, delimiter=sep))
    columns = list(cohort[omics + "_raw_column"])
    positions = []
    for column in columns:
        if header.count(column) != 1:
            raise RuntimeError(f"STOP: frozen sample column missing/duplicated: {column}")
        positions.append(header.index(column))
    usecols = sorted([0] + positions)
    order = [usecols.index(position) for position in positions]
    path = out / f"{omics}.npy"
    partial = path.with_name(path.name + ".partial")
    if path.exists() or partial.exists():
        raise FileExistsError(path)
    matrix = np.lib.format.open_memmap(partial, mode="w+", dtype="<f4",
                                      shape=(EXPECTED_FEATURES[omics], len(cohort)))
    feature_path = out / f"{omics}_features.tsv"
    digest = hashlib.sha256()
    sample_missing = np.zeros(len(cohort), dtype=np.int64)
    n_features, seen = 0, set()
    before = source.stat()
    reader = pd.read_csv(source, sep=sep, usecols=usecols, names=list(range(len(header))),
                         header=0, dtype=str, keep_default_na=False, encoding="utf-8-sig",
                         skip_blank_lines=False, on_bad_lines="error", chunksize=512,
                         compression="infer")
    try:
        with reader, feature_path.open("w", encoding="utf-8", newline="") as feature_handle:
            writer = csv.writer(feature_handle, delimiter="\t")
            writer.writerow(["feature_id", "source_feature_id", "source_data_row", "annotation::" + header[0]])
            for chunk in reader:
                feature_names = chunk.iloc[:, 0].astype(str).str.strip().tolist()
                for value in feature_names:
                    if not value or value in seen:
                        raise RuntimeError(f"STOP: invalid/repeated {omics} feature {value!r}")
                    seen.add(value)
                values = _numeric_block(chunk.iloc[:, order], omics)
                stop = n_features + len(values)
                if stop > EXPECTED_FEATURES[omics]:
                    raise RuntimeError(f"STOP: too many {omics} source features")
                matrix[n_features:stop] = values
                digest.update(values.tobytes(order="C"))
                sample_missing += np.isnan(values).sum(axis=0)
                for offset, (name, annotation) in enumerate(zip(feature_names, chunk.iloc[:, 0])):
                    writer.writerow([omics + "::" + name, name, n_features + offset + 1, annotation])
                n_features = stop
                if n_features % (512 * 50) == 0:
                    logger(f"{omics}: materialized {n_features:,}/{EXPECTED_FEATURES[omics]:,} features")
        matrix.flush()
    finally:
        matrix._mmap.close()
    after = source.stat()
    if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
        raise RuntimeError("STOP: source input changed during materialization")
    if n_features != EXPECTED_FEATURES[omics] or (sample_missing == n_features).any():
        raise RuntimeError(f"STOP: {omics} feature count or entirely missing patient mismatch")
    feature_hash = sha256_file(feature_path)
    if feature_hash != FEATURE_FILE_HASHES[omics]:
        raise RuntimeError(f"STOP: {omics} historical feature-order file SHA-256 mismatch: {feature_hash}")
    os.replace(partial, path)
    pd.DataFrame({"patient_id": cohort.patient_id, "raw_column": columns,
                  "raw_column_position": positions, "omics": omics}).to_csv(
        out / f"{omics}_column_selection.tsv", sep="\t", index=False, lineterminator="\n")
    pd.DataFrame({"patient_id": cohort.patient_id, "missing_features": sample_missing,
                  "total_features": n_features, "missing_fraction": sample_missing / n_features}).to_csv(
        out / f"{omics}_sample_qc.tsv", sep="\t", index=False, lineterminator="\n")
    result = {"matrix_file": path.name, "feature_file": feature_path.name,
              "shape_features_by_patients": [n_features, len(cohort)], "dtype": "<f4",
              "aligned_payload_sha256": digest.hexdigest(), "npy_sha256": sha256_file(path),
              "feature_file_sha256": feature_hash, "historical_feature_file_match": True,
              "source_header_sha256": hashlib.sha256(json.dumps(header).encode()).hexdigest(),
              "source_file": source.name, "source_size_bytes": before.st_size,
              "source_sha256": sha256_file(source)}
    write_json(out / f"{omics}_materialization.json", result)
    logger(f"{omics}: complete {n_features:,} features x {len(cohort)} frozen patients")
    return result


class FeatureDataset:
    """Feature-major float32 storage read in bounded patient/feature blocks."""
    def __init__(self, cache_dir: Path, omics: str, patient_ids: Sequence[str], metadata: dict):
        self.omics = omics
        self.patient_ids = tuple(map(str, patient_ids))
        self._index = {p: i for i, p in enumerate(self.patient_ids)}
        self._matrix = np.load(cache_dir / metadata["matrix_file"], mmap_mode="r")
        self.shape = self._matrix.shape
        if self.shape != tuple(metadata["shape_features_by_patients"]) or self._matrix.dtype != np.dtype("<f4"):
            raise RuntimeError("STOP: raw materialized matrix shape/dtype mismatch")
        features = pd.read_csv(cache_dir / metadata["feature_file"], sep="\t", dtype=str)
        self.feature_ids = tuple(features.feature_id)
        self.source_feature_ids = tuple(features.source_feature_id)
        self.access_events: list[dict] = []
        self._scope: frozenset[str] | None = None
        self._stage = "unconfigured"

    def patient_indices(self, patient_ids: Iterable[str]) -> np.ndarray:
        ids = tuple(map(str, patient_ids))
        if len(set(ids)) != len(ids) or set(ids).difference(self._index):
            raise ValueError("Unknown or repeated patient IDs")
        return np.asarray([self._index[p] for p in ids], dtype=np.int64)

    def set_access_scope(self, *, stage: str, allowed_patient_ids: Iterable[str], purpose: str = "") -> None:
        ids = tuple(map(str, allowed_patient_ids))
        self.patient_indices(ids)
        self._scope, self._stage = frozenset(ids), stage
        self.access_events.append({"event": "scope", "stage": stage, "purpose": purpose,
                                   "n_patients": len(ids), "patient_ids_sha256": sha256_lines(ids)})

    def read_feature_block(self, patient_ids: Iterable[str], start: int, stop: int) -> np.ndarray:
        ids = tuple(map(str, patient_ids))
        if self._scope is None or set(ids).difference(self._scope):
            raise PermissionError("Read requires a configured patient access scope")
        if not 0 <= start <= stop <= self.shape[0]:
            raise ValueError("Invalid feature block")
        indices = self.patient_indices(ids)
        self.access_events.append({"event": "read", "stage": self._stage, "n_patients": len(ids),
                                   "feature_start": start, "feature_stop": stop})
        return self._matrix[start:stop, indices].T

    def close(self) -> None:
        self._matrix._mmap.close()


@dataclass
class FoldPreprocessor:
    omics: str
    max_feature_missing: float = 0.2
    mrna_min_expressed_samples: int = 3
    mrna_expression_threshold_tpm: float = 1.0
    block_features: int = 512

    def fit(self, dataset: FeatureDataset, patient_ids: Iterable[str]) -> "FoldPreprocessor":
        if self.omics not in {"mrna", "methyl"} or dataset.omics != self.omics:
            raise ValueError("Only the two authorized Branch A omics are supported")
        if (self.max_feature_missing != 0.2 or self.mrna_min_expressed_samples != 3
                or self.mrna_expression_threshold_tpm != 1.0):
            raise ValueError("Frozen preprocessing configuration cannot be changed")
        ids = tuple(map(str, patient_ids))
        if not ids:
            raise ValueError("Cannot fit on an empty training fold")
        dataset.patient_indices(ids)
        selected, fills, offsets, divisors = [], [], [], []
        reasons = np.zeros(dataset.shape[0], dtype=np.uint8)
        missing_counts = np.zeros(dataset.shape[0], dtype=np.int64)
        expressed_counts = np.full(dataset.shape[0], -1, dtype=np.int64)
        for start in range(0, dataset.shape[0], self.block_features):
            stop = min(start + self.block_features, dataset.shape[0])
            raw = np.asarray(dataset.read_feature_block(ids, start, stop), dtype=np.float32)
            observed = raw[~np.isnan(raw)]
            if np.isinf(observed).any() or (observed.size and ((observed < 0).any()
                    or (self.omics == "methyl" and (observed > 1).any()))):
                raise ValueError("Invalid raw preprocessing numeric domain")
            missing_counts[start:stop] = np.isnan(raw).sum(axis=0)
            eligible = np.mean(np.isnan(raw), axis=0, dtype=np.float64) <= self.max_feature_missing
            codes = np.where(eligible, 0, 1).astype(np.uint8)
            if self.omics == "mrna":
                expressed = (raw >= self.mrna_expression_threshold_tpm).sum(axis=0)
                expressed_counts[start:stop] = expressed
                low = expressed < self.mrna_min_expressed_samples
                codes[eligible & low] = 2
                eligible &= ~low
            columns = np.flatnonzero(eligible)
            if len(columns):
                values = raw[:, columns]
                variable = np.nanmax(values, axis=0) > np.nanmin(values, axis=0)
                codes[columns[~variable]] = 3
                columns = columns[variable]
            reasons[start:stop] = codes
            if not len(columns):
                continue
            values = raw[:, columns].astype(np.float64)
            if self.omics == "mrna":
                values = np.log2(values + 1.0)
            fill = np.nanmedian(values, axis=0)
            values = np.where(np.isnan(values), fill, values)
            offset = values.mean(axis=0, dtype=np.float64) if self.omics == "mrna" else np.zeros(len(columns))
            divisor = values.std(axis=0, ddof=0, dtype=np.float64) if self.omics == "mrna" else np.ones(len(columns))
            divisor[divisor == 0] = 1.0
            if not np.isfinite((values - offset) / divisor).all():
                raise ValueError("Nonfinite training preprocessing output")
            selected.append((start + columns).astype(np.int64))
            fills.append(fill.astype(np.float32))
            offsets.append(offset.astype(np.float32))
            divisors.append(divisor.astype(np.float32))
        if not selected:
            raise ValueError("Preprocessing retained no training features")
        self.kept_indices_ = np.concatenate(selected)
        self.feature_ids_ = tuple(dataset.feature_ids[i] for i in self.kept_indices_)
        self.source_feature_ids_ = tuple(dataset.source_feature_ids[i] for i in self.kept_indices_)
        self.fill_values_ = np.concatenate(fills)
        self.offsets_ = np.concatenate(offsets)
        self.divisors_ = np.concatenate(divisors)
        self.train_patient_ids_ = ids
        self.drop_reason_codes_, self.missing_counts_, self.expressed_counts_ = reasons, missing_counts, expressed_counts
        self.audit_ = {"omics": self.omics, "n_training_patients": len(ids),
                       "n_raw_features": dataset.shape[0], "n_retained": len(self.kept_indices_),
                       "removed_missing": int(np.count_nonzero(reasons == 1)),
                       "removed_low_expression": int(np.count_nonzero(reasons == 2)),
                       "removed_constant": int(np.count_nonzero(reasons == 3)),
                       "training_patient_ids_sha256": sha256_lines(ids),
                       "retained_feature_ids_sha256": sha256_lines(self.feature_ids_),
                       "training_only_fit": True, "state_digest": self.state_digest(),
                       "provenance": PREPROCESSING_PROVENANCE}
        return self

    def transform_to_file(self, dataset: FeatureDataset, patient_ids: Iterable[str], output_path: str | Path) -> Path:
        if not hasattr(self, "kept_indices_"):
            raise RuntimeError("Preprocessor is not fitted")
        ids = tuple(map(str, patient_ids))
        dataset.patient_indices(ids)
        output = Path(output_path)
        output.parent.mkdir(parents=True, exist_ok=True)
        partial = output.with_name(output.name + ".partial")
        if output.exists() or partial.exists():
            raise FileExistsError(output)
        matrix = np.lib.format.open_memmap(partial, mode="w+", dtype=np.float32,
                                          shape=(len(ids), len(self.kept_indices_)))
        try:
            for start in range(0, dataset.shape[0], self.block_features):
                stop = min(start + self.block_features, dataset.shape[0])
                left = int(np.searchsorted(self.kept_indices_, start))
                right = int(np.searchsorted(self.kept_indices_, stop))
                if left == right or not ids:
                    continue
                raw = dataset.read_feature_block(ids, start, stop)
                values = raw[:, self.kept_indices_[left:right] - start].astype(np.float64)
                if self.omics == "mrna":
                    values = np.log2(values + 1.0)
                values = np.where(np.isnan(values), self.fill_values_[left:right], values)
                values = (values - self.offsets_[left:right]) / self.divisors_[left:right]
                if not np.isfinite(values).all():
                    raise ValueError("Nonfinite validation/test preprocessing output")
                matrix[:, left:right] = values.astype(np.float32)
            matrix.flush()
        finally:
            matrix._mmap.close()
        os.replace(partial, output)
        return output

    def state_digest(self) -> str:
        digest = hashlib.sha256()
        digest.update(self.omics.encode())
        for values in (self.kept_indices_, self.fill_values_, self.offsets_, self.divisors_):
            array = np.asarray(values)
            digest.update(str(array.dtype).encode())
            digest.update(str(array.shape).encode())
            digest.update(array.tobytes())
        digest.update("\n".join(self.feature_ids_).encode())
        digest.update("\n".join(self.train_patient_ids_).encode())
        return digest.hexdigest()
