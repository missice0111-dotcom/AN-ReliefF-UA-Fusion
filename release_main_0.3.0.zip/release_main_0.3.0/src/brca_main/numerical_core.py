from __future__ import annotations
from dataclasses import dataclass
import numpy as np
CLASS_ORDER=("Luminal A","Luminal B","HER2-enriched","Basal-like")
N_CLASSES=len(CLASS_ORDER)
TIE_TOLERANCE=1e-12

@dataclass(frozen=True)
class Ranking:
    method: str
    k: int | None
    candidate_ids: np.ndarray
    anova_scores: np.ndarray
    relief_scores: np.ndarray
    order: np.ndarray
    diagnostics: dict[str, object]

    @property
    def ranked_ids(self) -> np.ndarray:
        return self.candidate_ids[self.order]


def anova_f_scores(X: np.ndarray, y: np.ndarray, block: int = 1024) -> np.ndarray:
    values = np.asarray(X)
    labels = np.asarray(y, dtype=np.int64)
    n, p = values.shape
    if labels.shape != (n,) or set(np.unique(labels)) != set(range(N_CLASSES)):
        raise ValueError("ANOVA requires all four classes")
    scores = np.full(p, -np.inf, dtype=np.float64)
    for start in range(0, p, block):
        stop = min(start + block, p)
        local = np.asarray(values[:, start:stop], dtype=np.float64)
        if not np.isfinite(local).all():
            raise ValueError("ANOVA input contains NaN or Inf")
        overall = local.mean(axis=0)
        between = np.zeros(stop - start, dtype=np.float64)
        within = np.zeros(stop - start, dtype=np.float64)
        for code in range(N_CLASSES):
            group = local[labels == code]
            if not len(group):
                raise ValueError("training fold misses a class")
            mean = group.mean(axis=0)
            between += len(group) * np.square(mean - overall)
            within += np.square(group - mean).sum(axis=0)
        numerator = between / (N_CLASSES - 1)
        denominator = within / (n - N_CLASSES)
        result = np.divide(
            numerator,
            denominator,
            out=np.full_like(numerator, np.inf),
            where=denominator > 0,
        )
        result[np.ptp(local, axis=0) == 0] = -np.inf
        scores[start:stop] = result
    return scores


def miss_prior_matrix(y: np.ndarray) -> np.ndarray:
    labels = np.asarray(y, dtype=np.int64)
    if set(np.unique(labels)) != set(range(N_CLASSES)):
        raise ValueError("miss priors require all four classes")
    counts = np.bincount(labels, minlength=N_CLASSES).astype(np.float64)
    n = len(labels)
    output = np.zeros((n, N_CLASSES), dtype=np.float64)
    for code in range(N_CLASSES):
        mask = labels != code
        output[mask, code] = counts[code] / (n - counts[labels[mask]])
    if not np.allclose(output.sum(axis=1), 1.0, rtol=0.0, atol=1e-12):
        raise ArithmeticError("four-class miss priors do not sum to one")
    return output


def _relief_scores(X: np.ndarray, coefficients: np.ndarray, block: int = 256) -> np.ndarray:
    values = np.asarray(X, dtype=np.float64)
    rows, columns = np.nonzero(coefficients)
    pair_weights = coefficients[rows, columns]
    ranges = np.ptp(values, axis=0)
    safe = np.where(ranges > 0, ranges, 1.0)
    output = np.zeros(values.shape[1], dtype=np.float64)
    for start in range(0, values.shape[1], block):
        stop = min(start + block, values.shape[1])
        differences = np.abs(values[rows, start:stop] - values[columns, start:stop])
        differences /= safe[start:stop]
        output[start:stop] = (pair_weights[:, None] * differences).sum(axis=0)
    output[ranges == 0] = -np.inf
    return output


def _ranking(
    method: str,
    k: int | None,
    ids: np.ndarray,
    anova: np.ndarray,
    relief: np.ndarray,
    diagnostics: dict[str, object],
) -> Ranking:
    order = np.lexsort((ids, -anova, -relief)).astype(np.int64)
    return Ranking(method, k, ids, anova, relief, order, diagnostics)


def uncertainty_features(probability: np.ndarray) -> np.ndarray:
    values = np.asarray(probability, dtype=np.float64)
    if values.ndim != 2 or values.shape[1] != N_CLASSES:
        raise ValueError("RNA probabilities must have four columns")
    if not np.isfinite(values).all() or not np.allclose(values.sum(axis=1), 1.0, atol=1e-6):
        raise ValueError("invalid RNA probabilities")
    ordered = np.sort(values, axis=1)
    clipped = np.clip(values, 1e-15, 1.0)
    return np.column_stack(
        [ordered[:, -1], ordered[:, -1] - ordered[:, -2], -np.sum(clipped * np.log(clipped), axis=1)]
    )
