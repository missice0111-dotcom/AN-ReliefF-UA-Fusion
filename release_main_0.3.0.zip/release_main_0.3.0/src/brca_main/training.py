from __future__ import annotations
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
import gc
from pathlib import Path
from time import perf_counter
from zoneinfo import ZoneInfo
import numpy as np
import pandas as pd
from .common import *
from .model_runner import XGBRunner, require
from .meta_engine import fit_meta, predict_meta, coefficient_rows, model_index

class Logger:
    def __init__(self,run):self.path=Path(run)/'logs/run.log';self.path.parent.mkdir(parents=True,exist_ok=True)
    def __call__(self,message):
        line=f'[{datetime.now(ZoneInfo("Asia/Shanghai")).isoformat(timespec="seconds")}] {message}';print(line,flush=True)
        with self.path.open('a',encoding='utf-8') as stream:stream.write(line+'\n')


def choose_geometry(rows):
    eligible=[x for x in rows if x['status']=='COMPLETE'];require(bool(eligible),'no feasible geometry')
    best=max(x['pooled_inner_macro_f1'] for x in eligible);ties=[x for x in eligible if best-x['pooled_inner_macro_f1']<=1e-12]
    return min(ties,key=lambda x:(x['top_m'],x['k'],0 if x['c'] is None else x['c'],0 if x['r'] is None else x['r'],x['config_id']))


def choose_xgb(rows):
    best=max(x['pooled_inner_macro_f1'] for x in rows)
    return min((x for x in rows if best-x['pooled_inner_macro_f1']<=1e-12),key=lambda x:x['candidate_index'])


def part_complete(run,r,o,identity):
    part=run/'parts'/f'r{r}_o{o}';marker=part/'complete.json'
    if not marker.exists():return False
    receipt=read_json(marker);require(receipt['status']=='COMPLETE' and receipt['scientific_identity']==identity,'completed context identity changed')
    for name,sha in receipt['artifact_sha256'].items():require(file_hash(part/name)==sha,'completed context changed:'+name)
    for phase in ('meta','predictions'):require(file_hash(run/f'locks/r{r}_o{o}_{phase}.json')==receipt[phase+'_lock_sha256'],'completed prediction/meta lock changed')
    return True


def pooled_scoring(data,runner,contexts,candidate,geom,family,ids,position,bridges):
    p=np.full((len(ids),4),np.nan)
    for ctx in contexts:
        selected=data.selected_context(ctx,family,geom)
        fit=runner.fit(selected,candidate);prob,receipt,path,hit=runner.predict(fit,selected)
        indexes=[position[x] for x in selected.validation_ids];require(np.isnan(p[indexes]).all(),'OOF rows duplicated');p[indexes]=prob
        bridges.append({'omic':ctx.omic,'repeat':ctx.repeat,'outer_fold':ctx.outer_fold,'inner_fold':ctx.inner_fold,'family':family,
                        'geometry_config_id':geom['config_id'],'xgb_config_id':candidate['config_id'],'selected_feature_hash':lines_hash(selected.feature_ids),
                        'selected_context_cache_key':selected.cache_key,'selected_context_manifest_path':str(selected.folder/'manifest.json'),
                        'fit_receipt_path':str(fit.path),'fit_receipt_sha256':file_hash(fit.path),'prediction_receipt_path':str(path),
                        'prediction_receipt_sha256':file_hash(path),'ensemble_path':receipt['ensemble_path'],'ensemble_sha256':receipt['ensemble_sha256'],
                        'training_ids_hash':lines_hash(selected.train_ids),'validation_ids_hash':lines_hash(selected.validation_ids),'outer_test_accessed':False})
    probability_guard(p,len(ids));return p


def select_omic(run,data,protocol,identity,r,o,omic,log):
    started=perf_counter();runner=XGBRunner(run,protocol);fold=data.folds[r,o];ids=fold['train_patient_ids'];position={p:j for j,p in enumerate(ids)};y=data.labels_for(ids)
    contexts=[data.context(omic,r,o,i) for i in (1,2,3)];scores={};selected={};bridges=[];anchor=protocol['xgboost_candidates'][0]
    folder=run/'parts'/f'r{r}_o{o}'/'base_selection'/omic;folder.mkdir(parents=True,exist_ok=True)
    # Independent anchor-scored geometry banks; selected XGB never feeds back.
    for family in ('C0','C2'):
        rows=[]
        for number,cfg in enumerate(protocol['geometry_banks'][family],1):
            issues=[{'inner_fold':ctx.inner_fold,'issues':data.feasibility(ctx,family,cfg)} for ctx in contexts]
            failed=[x for x in issues if x['issues']]
            row={'omic':omic,'repeat':r,'outer_fold':o,'family':family,**cfg,'selection_xgb_config_id':'XGB_00','outer_test_accessed':False}
            if failed:row.update(status='INFEASIBLE',pooled_inner_macro_f1=None,n_inner_folds=0,true_infeasible_reason=json.dumps(failed))
            else:
                p=pooled_scoring(data,runner,contexts,anchor,cfg,family,ids,position,bridges)
                row.update(status='COMPLETE',pooled_inner_macro_f1=metric_values(y,p)['macro_f1'],n_inner_folds=3,inner_oof_n=len(ids),true_infeasible_reason='')
            rows.append(row)
            if number%16==0:log(f'r{r}o{o} {omic} {family}: {number}/{len(protocol["geometry_banks"][family])} anchor-scored geometry candidates')
        scores[family]=rows;winner=choose_geometry(rows);selected[family]=next(x for x in protocol['geometry_banks'][family] if x['config_id']==winner['config_id'])
        write_tsv(folder/f'{family}_all_candidate_scores.tsv',rows);write_tsv(folder/f'{family}_selected.tsv',[winner])
        immutable_json(folder/f'{family}_GEOMETRY_SELECTION_LOCK.json',{'status':'ANCHOR_GEOMETRY_LOCKED','omic':omic,'repeat':r,'outer_fold':o,
                       'scientific_identity_hash':object_hash(identity),'selected_config':selected[family],'anchor':'XGB_00','selection_classifier_parameters':anchor['parameters'],
                       'candidate_scores_sha256':file_hash(folder/f'{family}_all_candidate_scores.tsv'),'outer_test_accessed':False})
    # Exact20 classifier search on the already-selected C0 feature maps only.
    rows=[]
    for candidate in protocol['xgboost_candidates']:
        p=pooled_scoring(data,runner,contexts,candidate,selected['C0'],'C0',ids,position,bridges)
        rows.append({'omic':omic,'repeat':r,'outer_fold':o,'family':'C0','config_id':candidate['config_id'],'candidate_index':candidate['candidate_index'],
                     'status':'COMPLETE','pooled_inner_macro_f1':metric_values(y,p)['macro_f1'],'n_inner_folds':3,'inner_oof_n':len(ids),
                     'geometry_config_id':selected['C0']['config_id'],'outer_test_accessed':False})
        log(f'r{r}o{o} {omic}: XGB {candidate["candidate_index"]+1}/20 on locked C0 features')
    chosen=choose_xgb(rows);classifier=next(x for x in protocol['xgboost_candidates'] if x['config_id']==chosen['config_id'])
    write_tsv(folder/'xgb_all_candidate_scores.tsv',rows);write_tsv(folder/'xgb_selected.tsv',[chosen])
    lock_path=run/'locks/base_selection'/omic/f'r{r}_o{o}.json'
    immutable_json(lock_path,{'status':'BASE_GEOMETRY_AND_XGB_LOCKED','scientific_identity_hash':object_hash(identity),'repeat':r,'outer_fold':o,'omic':omic,
                   'selected_geometry':selected,'selected_xgb_config':classifier,'geometry_selection_classifier':'XGB_00','classifier_selection_feature_family':'C0',
                   'shared_classifier_for_C0_C2':True,'selection_sequence':list(SELECTION_SEQUENCE),'outer_test_accessed':False,
                   'geometry_score_sha256':{f:file_hash(folder/f'{f}_all_candidate_scores.tsv') for f in ('C0','C2')},'xgb_score_sha256':file_hash(folder/'xgb_all_candidate_scores.tsv')})
    probabilities={f:pooled_scoring(data,runner,contexts,classifier,selected[f],f,ids,position,bridges) for f in ('C0','C2')}
    write_tsv(folder/'candidate_model_bridges.tsv',bridges);write_tsv(folder/'base_runtime.tsv',list(runner.runtime.values()));write_tsv(folder/'base_probability_audit.tsv',list(runner.guards.values()))
    log(f'r{r}o{o} {omic}: C0/C2/XGB locked in required order; strict OOF complete; {perf_counter()-started:.1f}s')
    return {'omic':omic,'selected':selected,'classifier':classifier,'probabilities':probabilities,'lock':lock_path,'contexts':contexts,'wall_seconds':perf_counter()-started}


def run_context(run,data,protocol,identity,r,o,log):
    if part_complete(run,r,o,identity):log(f'r{r}o{o} already complete; unchanged locks/artifacts verified');return
    validate_identity(run);part=run/'parts'/f'r{r}_o{o}';part.mkdir(parents=True,exist_ok=True);began=perf_counter()
    with ThreadPoolExecutor(max_workers=2,thread_name_prefix='route_b_omic') as pool:
        values=list(pool.map(lambda omic:select_omic(run,data,protocol,identity,r,o,omic,log),('mrna','methyl')))
    base={x['omic']:x for x in values};fold=data.folds[r,o];ids=fold['train_patient_ids'];position={p:j for j,p in enumerate(ids)};y=data.labels_for(ids);folds=np.zeros(len(ids),dtype=np.int64)
    for inner in fold['inner_folds']:folds[[position[p] for p in inner['validation_patient_ids']]]=inner['inner_fold']
    oof={};science=object_hash(identity)
    for family in ('C0','C2'):
        metadata={'patient_ids':ids,'fold_ids_digest':array_digest(folds),'labels_digest':array_digest(y),'family':family,
                  'P_rna_digest':array_digest(base['mrna']['probabilities'][family]),'P_methyl_digest':array_digest(base['methyl']['probabilities'][family]),
                  'base_selection_lock_sha256':{o:file_hash(base[o]['lock']) for o in base},'scientific_identity_hash':science}
        oof[family]=object_hash(metadata);checkpoint=run/'checkpoints'/f'r{r}_o{o}_{family}_oof';immutable_json(checkpoint.with_suffix('.json'),metadata)
        for name,array in (('rna',base['mrna']['probabilities'][family]),('methyl',base['methyl']['probabilities'][family]),('y',y),('folds',folds)):write_array(checkpoint.with_name(checkpoint.name+'_'+name+'.npy'),array)
    selected={};meta_scores=[];fitrefs={};fits={};coefs=[];runtime=[];logical=[];guards=[]
    for variant in VARIANTS[1:]:
        family='C0' if variant==VARIANTS[3] else 'C2';rna=base['mrna']['probabilities'][family];meth=base['methyl']['probabilities'][family];rows=[];start=perf_counter()
        for number,cfg in enumerate(candidates(variant),1):
            X,names=meta_features(rna,meth,cfg['subset_id']);p=np.full((len(ids),4),np.nan)
            for inner in (1,2,3):
                tr=folds!=inner;va=folds==inner;fit=fit_meta(run,X[tr],y[tr],np.asarray(ids)[tr],names,cfg,(r,o),'inner',inner,science,oof[family])
                prob,pr,guard,hit=predict_meta(run,fit,X[va],np.asarray(ids)[va],'inner',inner);p[va]=prob
                logical.append({'repeat':r,'outer_fold':o,'variant':variant,**cfg,**model_index(fit,pr,cfg,(r,o),'inner',inner)})
                guards.append({'repeat':r,'outer_fold':o,'variant':variant,**guard})
            rows.append({'repeat':r,'outer_fold':o,'variant':variant,**cfg,'status':'COMPLETE','pooled_meta_macro_f1':metric_values(y,p)['macro_f1'],
                         'n_meta_folds':3,'meta_oof_n':len(ids),'outer_test_accessed_for_selection':False})
            if number%10==0:log(f'r{r}o{o} {variant}: {number}/{len(candidates(variant))} frozen meta candidates')
        selected[variant]=choose_candidate(rows,variant);meta_scores.extend(rows)
        X,names=meta_features(rna,meth,selected[variant]['subset_id']);fit=fit_meta(run,X,y,ids,names,selected[variant],(r,o),'outer',None,science,oof[family]);fits[variant]=fit
        fitrefs[variant]={'path':str(fit.receipt_path),'sha256':file_hash(fit.receipt_path)};coefs.extend(coefficient_rows(fit,variant,r,o,selected[variant]))
        runtime.append({'repeat':r,'outer_fold':o,'variant':variant,'stage':'meta_search_and_final','wall_seconds':perf_counter()-start,'logical_candidates':len(rows)})
    write_tsv(part/'all_meta_candidate_scores.tsv',meta_scores);write_tsv(part/'selected_meta_config.tsv',list(selected.values()));write_tsv(part/'meta_coefficients.tsv',coefs)
    write_tsv(part/'meta_model_index.tsv',logical);write_tsv(part/'meta_probability_audit.tsv',guards)
    joint=run/f'locks/r{r}_o{o}_meta.json'
    immutable_json(joint,{'status':'META_PARAMETERS_AND_MODELS_LOCKED','scientific_identity_hash':science,'repeat':r,'outer_fold':o,
                   'outer_training_ids_hash':lines_hash(ids),'selected_configs':selected,'base_selection_locks':{omic:{'path':str(x['lock']),'sha256':file_hash(x['lock'])} for omic,x in base.items()},
                   'base_oof_identity_hash_by_family':oof,'final_model_receipts':fitrefs,'outer_test_accessed':False})
    outer={};base_predictions=[];runner=XGBRunner(run,protocol)
    for omic in ('mrna','methyl'):
        ctx=data.context(omic,r,o,None)
        for family in ('C0','C2'):
            selectedctx=data.selected_context(ctx,family,base[omic]['selected'][family]);fit=runner.fit(selectedctx,base[omic]['classifier'])
            transformed=data.transform_outer(selectedctx,joint);p,receipt,path,hit=runner.predict(fit,transformed,joint);outer[omic,family]=p
            base_predictions.append({'omic':omic,'family':family,'fit_receipt_path':str(fit.path),'fit_receipt_sha256':file_hash(fit.path),
                                     'prediction_receipt_path':str(path),'prediction_receipt_sha256':file_hash(path),'selected_context_manifest_path':str(selectedctx.folder/'manifest.json')})
    write_tsv(part/'outer_base_model_index.tsv',base_predictions);write_tsv(part/'outer_base_runtime.tsv',list(runner.runtime.values()));write_tsv(part/'outer_base_probability_audit.tsv',list(runner.guards.values()))
    probability={VARIANTS[0]:outer['mrna','C2']};predrefs={};testids=fold['test_patient_ids']
    for variant in VARIANTS[1:]:
        family='C0' if variant==VARIANTS[3] else 'C2';cfg=selected[variant];X,_=meta_features(outer['mrna',family],outer['methyl',family],cfg['subset_id'])
        p,receipt,guard,hit=predict_meta(run,fits[variant],X,testids,'outer',None,joint);probability[variant]=p
        predrefs[variant]={'path':receipt['prediction_path'],'sha256':receipt['prediction_sha256']}
    path=part/'rna_only_probabilities.npy';write_array(path,probability[VARIANTS[0]]);predrefs[VARIANTS[0]]={'path':str(path),'sha256':file_hash(path)}
    prediction_lock=run/f'locks/r{r}_o{o}_predictions.json'
    immutable_json(prediction_lock,{'status':'OUTER_META_PREDICTIONS_COMPLETE','scientific_identity_hash':science,'repeat':r,'outer_fold':o,
                   'joint_meta_lock_path':str(joint),'joint_meta_lock_sha256':file_hash(joint),'patient_ids_hash':lines_hash(testids),'predictions':predrefs,'outer_test_labels_accessed':False})
    # The only outer-label evaluation entry point follows all four prediction locks.
    testy=data.labels_for(testids);rows=[]
    for variant,p in probability.items():
        probability_guard(p,len(testids))
        for j,patient in enumerate(testids):rows.append({'variant':variant,'repeat':r,'outer_fold':o,'patient_id':patient,'true_label':int(testy[j]),'predicted_label':int(p[j].argmax()),**{'probability::'+name:float(p[j,c]) for c,name in enumerate(CLASS_NAMES)}})
    write_tsv(part/'predictions.tsv',rows);runtime.append({'repeat':r,'outer_fold':o,'variant':'SHARED_BASE','stage':'whole_context','wall_seconds':perf_counter()-began})
    write_tsv(part/'runtime.tsv',runtime)
    immutable_json(part/'outer_label_access.json',{'status':'OUTER_LABELS_ONLY_AFTER_ALL_FOUR_PREDICTIONS','prediction_lock_sha256':file_hash(prediction_lock),'joint_lock_sha256':file_hash(joint),
                   'patient_ids_hash':lines_hash(testids),'labels_digest':array_digest(testy),'outer_test_used_for_selection':False})
    immutable_json(part/'complete.json',{'status':'COMPLETE','repeat':r,'outer_fold':o,'scientific_identity':identity,'meta_lock_sha256':file_hash(joint),'predictions_lock_sha256':file_hash(prediction_lock),
                   'artifact_sha256':{p.relative_to(part).as_posix():file_hash(p) for p in sorted(part.rglob('*')) if p.is_file() and p.name!='complete.json'},'protocol_changed':False,'selection_order_changed':False,'outer_test_used_for_selection':False})
    data.flush_audits();data.release_contexts(r,o);gc.collect();log(f'r{r}o{o}: FOUR VARIANTS COMPLETE; mandatory selection order preserved')
