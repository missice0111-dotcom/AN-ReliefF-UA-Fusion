from __future__ import annotations
import hashlib
from time import perf_counter
import numpy as np
from .geometry import EuclideanContext, CLASS_NAMES, MULTIPLIERS, historical

def feasibility(labels, k, c=None, r=None, *, mechanism, scale_scope="global_nonself", legacy_clipping=False):
    """Clipping cannot repair fewer than k eligible neighbors or fewer than r*k global neighbors."""
    if mechanism not in {"C0", "C2"} or scale_scope != "global_nonself":
        raise ValueError("Stage 2B freezes C0/C2 with global_nonself local scales")
    if not isinstance(k, (int, np.integer)) or k <= 0:
        raise ValueError("k must be a positive integer")
    y = np.asarray(labels, dtype=np.int64)
    if y.ndim != 1 or not len(y) or np.any((y < 0) | (y >= 4)):
        raise ValueError("Four-class labels must be a nonempty one-dimensional integer array")
    if mechanism == "C2" and (c not in MULTIPLIERS or r not in MULTIPLIERS):
        raise ValueError("C2 c/r must belong to the frozen 2/3/4 grid")
    counts = np.bincount(y, minlength=4)
    issues = []
    for target, count in enumerate(counts):
        available = int(count) - 1
        if available < k:
            issues.append({"class": CLASS_NAMES[target], "component": "selected_neighbors",
                           "available_n": available, "required_n": int(k)})
    if mechanism == "C2" and len(y) - 1 < r * k:
        issues.append({"class": "GLOBAL_NONSELF", "component": "local_scale",
                       "available_n": len(y) - 1, "required_n": int(r * k)})
    return issues

class ClippedEuclideanContext(EuclideanContext):
    def rank(self, *, k, c=None, r=None, mechanism, scale_scope="global_nonself", legacy_clipping=False, method="C2"):
            started = perf_counter()
            issues = feasibility(self.labels, k, c, r, mechanism=mechanism, scale_scope=scale_scope,
                                 legacy_clipping=legacy_clipping)
            if issues:
                raise ValueError(f"INFEASIBLE_GEOMETRY: {issues}")
            if legacy_clipping:
                assert mechanism == "C2" and scale_scope == "global_nonself"
            neighbors = np.empty((self.n, 4, k), dtype=np.int64)
            for target in range(4):
                scale = self._scale(r * k, scale_scope, None) if mechanism == "C2" else None
                for anchor in range(self.n):
                    ordered = self.class_sorted[target][anchor]
                    if mechanism == "C0":
                        selected = ordered[:k]
                    else:
                        pool = ordered[:min(c * k, len(ordered))]
                        denominator = np.maximum(scale[anchor] * scale[pool], np.finfo(float).eps)
                        affinity = np.exp(-np.square(self.distances[anchor, pool]) / denominator)
                        affinity[~np.isfinite(affinity)] = 0.0
                        order = np.lexsort((pool, self.distances[anchor, pool], -affinity))
                        selected = pool[order[:k]]
                    neighbors[anchor, target] = selected
            # Verbatim accepted WHO/update, weighting, prior and full score vector.
            score_key = (k, hashlib.sha256(neighbors.tobytes()).hexdigest())
            if score_key not in self._scores:
                coefficients = np.zeros((self.n, self.n), dtype=np.float64)
                for anchor in range(self.n):
                    own = int(self.labels[anchor])
                    for target in range(4):
                        mass = -1.0 if target == own else self.prior[anchor, target]
                        coefficients[anchor, neighbors[anchor, target]] += mass / (self.n * k)
                self._scores[score_key] = historical._relief_scores(self.values, coefficients)
            else:
                self.scoring_cache_hits += 1
            scores = self._scores[score_key]
            ranking = historical._ranking(method, k, self.feature_ids, self.anova, scores, {
                "distance_space": "training_z_standardized_euclidean", "local_scale_scope": scale_scope,
                "k": k, "c": c, "r": r, "legacy_candidate_clipping": legacy_clipping,
                "candidate_pool_clipping": mechanism == "C2",
                "selected_neighbor_weight": "1/k", "anchor_mass": "1/n"})
            return ranking, neighbors, perf_counter() - started
