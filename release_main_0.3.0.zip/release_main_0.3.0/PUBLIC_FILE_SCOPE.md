# Author-confirmed public file scope

The author has confirmed this main-only scope and the MIT License. `FILE_MANIFEST.tsv` lists the exact package payload and checksums, excluding itself. The package has been prepared locally; public repository availability has not yet been verified.

| Included group | Content |
|---|---|
| Source and installation | Actual final preprocessing/ANOVA, ReliefF/AN-ReliefF, shared XGBoost, stacking/UA-Fusion, OOF/nested CV, metrics and final main Bootstrap code; complete local numerical dependencies, public CLI, package/build metadata, requirements and `.gitignore`. |
| Scientific specification | Complete 16/144/20/10/70 candidate spaces, enumeration/selection/tie rules, model/meta settings, seeds, immutable scientific-config and split guards. |
| Cohort and features | TCGA patient/subtype/raw-column mapping for 738 patients, frozen 3x5x3 partitions and selected feature identifiers/hashes. |
| Existing main reference outputs | Aggregate metrics and paired differences, final Bootstrap confidence intervals, selected C0/C2/shared XGBoost settings and all 45 final S1/S2 settings. |
| Documentation and attribution | README, input access/schema, scope/changes, validation summary, safe relative provenance/checksums, citation information, the MIT License and third-party notices. Code Availability and reviewer-response working drafts are excluded. |

Not included: raw or processed molecular matrices, subtype workbook, trained models, patient predictions, candidate model libraries, historical all-Meta candidate scores, replicate resampling banks, fitted coefficients, logs, internal audits/checkpoints, private conversations or authorization, old Git history, abandoned/history workflows, Gaussian/PAM50-exclusion/enrichment/R and other supplemental experiments.

The primary research code is licensed under MIT, Copyright (c) 2026 Bing Zheng. Third-party terms apply to their respective dependencies. The code license does not establish permission to distribute molecular inputs or future prediction/model attachments, which are outside this package. Repository publication and anonymous access remain to be verified.
