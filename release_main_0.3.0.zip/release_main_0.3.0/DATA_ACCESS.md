# Input access and source provenance

This package contains no molecular-value matrix, input workbook, model or patient-level prediction attachment. The frozen cohort/sample mapping, partitions, selected feature identifiers and aggregate results are included under the author-confirmed scope.

The author confirms that the study data were downloaded from the UCSC-hosted TCGA Pan-Cancer (PANCAN) resource. The [UCSC Xena public data pages](https://xenabrowser.net/datapages/) and [official TCGA resource description](https://ucsc-xena.gitbook.io/project/public-data-we-host/tcga) are access entry points. This confirmation identifies the platform and collection, but not the exact hub, dataset download URLs, upstream release or acquisition dates of the individual historical inputs. These details remain unresolved; current data products must not be described as byte-identical to the paper's inputs without evidence.

The historical mRNA input was supplied on the TPM scale. Its exact dataset/export filename and upstream endpoint, TPM conversion or export procedure, and reference annotation remain unresolved. The platform confirmation alone does not establish a particular UCSC expression product or processing pipeline.

The methylation source history refers to the Pan-Cancer HumanMethylation450 beta-value resource. The exact BRCA extraction chain, individual dataset endpoint, upstream release and acquisition date remain unresolved. The main pipeline uses only the raw sample columns in the released 738-patient mapping.

The subtype input contract is a workbook with sheet `TCGASubtype.20170308` and fields `sampleID` / `Subtype_mRNA`. The precise original workbook conversion/download chain remains unresolved. File modification dates are not evidence of data acquisition dates.

The [NCI Genomic Data Commons](https://gdc.cancer.gov/access-data) is a related TCGA data platform; it is not asserted to be the direct download source of the inputs used in this study. Follow applicable input-specific access and redistribution terms. The code accepts user-supplied files and does not download or substitute another molecular dataset.

`config/input_schema.json` records the exact shapes, dtype and feature-list checksums of the accepted materialization. `data/cohort.tsv` and `data/splits.json` define frozen cohort, labels and partitions. Input contract conformity alone does not prove molecular-value identity or reproduce the reference results. No missing input is replaced by synthetic or approximate values. Code licensing does not assign a new license to TCGA data.
