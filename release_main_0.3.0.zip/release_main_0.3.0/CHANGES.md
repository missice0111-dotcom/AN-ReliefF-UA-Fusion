# Main-only package changes

## Retained

The executed main numerical functions and complete local numerical dependencies; fold-fitted raw preprocessing and ANOVA; Standard ReliefF reference selection, AN-ReliefF, shared native XGBoost configuration, strict base OOF construction, S1 and UA-Fusion S2, repeated nested CV, metrics and H1-H3 direct contrasts. All actual candidate dictionaries, their ordering, score/tie rules, seeds, frozen partitions, sample mapping and selected feature identifiers remain present. Existing aggregate and selected-parameter tables are preserved. The Meta selection table is renamed to describe all 45 S1/S2 rows rather than suggesting only S2 parameters.

The actual final main-result patient-cluster Bootstrap functions and computation block are extracted with user-input routing, and existing aggregate intervals are included. The fixed 1,000 resamples, seed, pairing, repeat-first aggregation, metrics and percentile interval method are retained. Real-data Bootstrap is not rerun.

Dependencies were traced by call/import use. Required numerical functions originating in predecessor or five-class source locations remain included; unrelated experiment launchers from those locations are omitted.

## Omitted from this new package

Early trial models and abandoned alternatives; exploratory/history launchers; duplicate source snapshots; private authorization, dialogue and review records; training logs; cached search/model objects; fitted coefficients; raw and processed molecular matrices; trained model files; patient predictions; historical all-Meta candidate scores; patient-associated Bootstrap resampling arrays; PAM50-exclusion, selector/classifier benchmarks, efficiency, feature-stability, Gaussian robustness, enrichment/R and extra plotting workflows. These materials were not deleted from the original study or prior candidate. Code that produces new inner-CV candidate scores and selects parameters remains included.

## Modified only in this public copy

The package layout and imports are relative. Required actual scientific functions are collected into one package rather than duplicated under historical folders. A new `prepare`, `train`, `summarize`, and `bootstrap` command-line layer accepts explicit input/configuration/output locations. Historical archive/private-authorization gates are replaced by guards for released scientific settings, frozen splits, input/cohort/features, file integrity, fold membership, OOF exclusions and model locks. Scientific formulae, preprocessing, candidate spaces/order, seeds, metrics and selection logic are retained. The summary output path is checked before reading inputs, and its directory is created only after input validation and metric computation; malformed input therefore does not create an empty summary directory.

H1/H2/H3 now correspond to R2-minus-R3/R0/R1, as in the final manuscript. Reporting labels that implied hypothesis proof are replaced by descriptive repeat-direction names. Their numerical mean/count criterion and all saved differences are unchanged. Scientific-protocol description keys and runtime filenames are adjusted accordingly, and the public configuration integrity pin is updated to its actual new object hash. Candidate banks, scoring, tie rules, selection sequence, seeds and preprocessing are unchanged.

Public provenance uses relative source identifiers and checksums. Raw materialization metadata records source filename/checksum instead of an original absolute path or file timestamp. Internal detailed equivalence/checkpoint records are outside the package; README/VALIDATION provide the public validation summary.

Environment and third-party notices separate the new isolated verification environment from recovered historical versions. Author-confirmed main CPU/RAM are added. The primary research-code MIT License is included, Copyright (c) 2026 Bing Zheng, as confirmed by the copyright holder. Build metadata, `.gitignore`, citation and publication-scope documentation are added. A fresh file manifest and separately checksummed ZIP replace no original frozen manifest or archive. Detailed file-level retained/excluded/modified ledgers and review receipts remain outside the package.

## Version 0.3.0 release preparation

Relative to the preceding local package, only licensing, non-numerical documentation and version metadata are updated. The package version in `pyproject.toml` and the pure `__version__` value in `src/brca_main/__init__.py` are `0.3.0`; no scientific source body, guard, configuration, cohort/split/feature file, reference result or provenance record is changed. The two Code Availability/reviewer-response working drafts are retained only in separate private review. `MANIFEST.in` includes the MIT License and excludes those drafts. The author-confirmed UCSC TCGA Pan-Cancer origin is recorded without inventing individual endpoints, dates, export/conversion details or workbook provenance. A fresh file manifest and ZIP are generated. No package installation, model or statistical operation is performed in this preparation, and verified public repository availability is not claimed.
