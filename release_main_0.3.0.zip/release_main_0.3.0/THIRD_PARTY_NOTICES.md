# Third-party dependencies and primary license status

The primary research code is licensed under the MIT License in `LICENSE`, Copyright (c) 2026 Bing Zheng, as confirmed by the copyright holder. Third-party dependency licenses continue to apply to their respective packages. Public repository availability has not yet been verified.

The main pipeline depends on separately installed NumPy, pandas, SciPy, scikit-learn, XGBoost, threadpoolctl, and openpyxl for the raw subtype-workbook reader. Their package sources and upstream notices remain applicable. Their installed package code, environment directories and binaries are not bundled in this package.

| Dependency | License recorded in the checked distribution | Upstream source |
|---|---|---|
| NumPy | BSD-style copyright and permission notice | https://github.com/numpy/numpy |
| pandas | BSD 3-Clause | https://github.com/pandas-dev/pandas |
| SciPy | BSD-style copyright and permission notice | https://github.com/scipy/scipy |
| scikit-learn | new BSD | https://github.com/scikit-learn/scikit-learn |
| XGBoost | Apache-2.0 | https://github.com/dmlc/xgboost |
| threadpoolctl | BSD-3-Clause | https://github.com/joblib/threadpoolctl |
| openpyxl | MIT | https://openpyxl.readthedocs.io/ |

These declarations were read from the installed distribution metadata used for the static/import review. They do not establish the license of this research code or grant redistribution permission for molecular data. Preserve upstream copyright and license information when obtaining or redistributing dependencies under their respective terms.

The ANOVA, Relief update, AN-ReliefF geometry, preprocessing, selection procedure and fusion arithmetic in this package come from the actual main analysis sources. Their numerical functions are tracked by source-function identifiers and checksum values in the public provenance manifest. Existing predecessor-folder names were assessed by dependency, rather than used as a reason to omit scientific functions.

Supplementary selector packages, R enrichment packages, biological database snapshots, font binaries and native figure-rendering tools are outside this main-only candidate. No raw molecular matrices, fitted models, or patient-level predictions are distributed.
