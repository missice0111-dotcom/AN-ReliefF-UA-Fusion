# Actual validation scope

The release preparation performs no model fitting, hyperparameter search, prediction, real-model loading, real metric recomputation or real-data Bootstrap. Existing reference numbers are copied, not regenerated. Installation and interface checks are separate from complete experimental reproduction.

The installation, build and guarded-interface checks below were completed for the preceding `0.3.0rc1` local package. Version `0.3.0` changes only package-version metadata, licensing and non-numerical documentation. Its scientific modules, complete configuration, cohort/splits/features, reference results and provenance records are byte-identical, except for the explicitly documented `__version__` metadata in `src/brca_main/__init__.py`. This final metadata/documentation copy was not rebuilt or reinstalled; its file differences, manifest, privacy scan and ZIP integrity were checked statically.

| Check | Actual scope and outcome |
|---|---|
| Manuscript correspondence | H1/H2/H3 matched to R2-minus-R3/R0/R1. Supplement tables matched the 20 XGBoost candidates, 60 selector settings, 30 final omic XGBoost IDs and 45 final fusion settings without numerical mismatch. Three DOCX files were read only; none is included. |
| Main scientific configuration | The complete candidate dictionaries/order, scoring, ties, seeds, selection sequence and preprocessing remain unchanged from the preceding candidate. Fifty-eight top-level scientific fields are identical; renamed descriptive reporting fields retain the original numeric direction rule. The public configuration pin matches the actual new object. |
| Main numerical source | All 17 modules parsed/compiled statically. Of 93 collected main source-symbol records, 91 retain exact ASTs; the two documented adaptations are raw source-receipt metadata and descriptive repeat-direction output labels. Numerical metric/selection/preprocessing bodies are unchanged. |
| Final statistical source | Five actual final Bootstrap numerical functions, scientific constants and the complete computation statement block match the original source ASTs. Seed/count/pairing/interval implementation is retained. Three existing aggregate interval tables match the final output receipt hashes byte for byte. |
| Final fusion parameters | `meta_selected_by_outer.tsv` contains 15 R1 ordinary-stacking, 15 R2 AN-ReliefF/UA-Fusion and 15 R3 Standard-ReliefF/UA-Fusion configurations. All C/subset/scaling/dimension values match the full candidate banks and supplementary tables. Fixed logistic-regression parameters remain in the scientific config. |
| Bootstrap input guards | Eleven structural input cases passed using synthetic placeholders only. Missing/invalid schema, coverage, labels, probabilities, patient identity and frozen folds are rejected. Every statistical calculation function was patched to prohibit calls; no metrics or resampling were computed. Invalid inputs did not create output. |
| Isolated dependency installation | A new private Python 3.12.10 environment installed the seven exact scientific/input dependencies. The original environment was not changed. Current build/installer versions are recorded separately from historical evidence. |
| Package build/install and installed interfaces | An sdist and a wheel built from that sdist were created in private staging. The wheel was installed non-editably without fetching dependencies, and `pip check` passed. Installed-module imports, the console/module entries, all four command helps and input-rejection checks passed under guards forbidding numerical/statistical execution, fitting, prediction and real-model loading. The preceding package's source payload was checked against its built artifacts and installed code; no build or installation was repeated for the final version-metadata/documentation copy. |
| Content and archive | The final directory and ZIP are scanned for machine/user paths, private addresses, tokens, conversation/authorization fields, excluded payloads and archive metadata. No unresolved findings remain. ZIP members match the directory and manifest SHA256 values, and archive CRC verification passed. Detailed internal reports remain outside the public directory and archive. |
| Original material protection | The 583 protected v2/prior-candidate files, source files, checkpoint and three manuscript documents retain their original size, modification time and SHA256; no protection mismatch was found. The v2 file roster is unchanged. |

Input-error tests use missing or synthetic files, not patient predictions. Fitting, prediction, model loading, networking and subprocess operations are prohibited during interface tests. Installation/build operations use a separate private environment and staging directory. Normal path manipulation and user-supplied absolute arguments are supported; hardcoded machine/private paths are excluded from the package payload.

The following remain **NOT_RUN**:

- Large raw-matrix preparation and training-fold preprocessing execution.
- Model fitting, actual inner-CV search, OOF/outer prediction or full 3x5x3 nested CV.
- Loading or predicting with a real saved model.
- Real patient-prediction metric recomputation or Bootstrap.
- Gaussian robustness, PAM50 exclusion, enrichment or other supplemental experiments.
- Complete paper-result reproduction.

Author-confirmed main hardware is AMD Ryzen 9 7950X3D with 64 GB RAM. The historical main Python version and Windows build are unknown. Current verification environment versions do not fill those gaps. Matching molecular inputs and predictions are not provided, and parts of the original acquisition/export chain remain unresolved. The author has confirmed the MIT License, Copyright (c) 2026 Bing Zheng, and the exact main-only payload. The package has been prepared locally; public repository availability has not yet been verified.
