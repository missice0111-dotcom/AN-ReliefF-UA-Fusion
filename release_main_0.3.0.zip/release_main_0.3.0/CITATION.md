# Citation information

This version `0.3.0` research-code package accompanies the manuscript:

Bing Zheng, Chunli Li, and Xiaoxia He. *Adaptive Neighborhood ReliefF and Uncertainty-Aware Multi-Omics Fusion for Breast Cancer Molecular Subtyping.*

The author names and title are taken from the corresponding manuscript. No manuscript publication year, journal, DOI or verified public code-repository URL is asserted. Update the bibliographic entry from the final publication once it exists.

Software copyright: Copyright (c) 2026 Bing Zheng. The primary research code is licensed under MIT; see `LICENSE` and `THIRD_PARTY_NOTICES.md`.

The package version is `0.3.0`. No public repository tag, commit or archived software DOI has yet been verified; this file is citation guidance for the prepared package rather than a claim of public archival or complete paper-result reproduction.
