# Main-only release scope

The final study uses 738 patients, mRNA and DNA methylation, and the class order Luminal A, Luminal B, HER2-enriched, Basal-like. It retains training-fold preprocessing and ANOVA, Standard ReliefF (C0), AN-ReliefF (C2), native CPU XGBoost, base OOF generation, probability fusion and uncertainty-aware fusion, repeated nested CV, performance metrics and the three direct comparisons below.

| Hypothesis comparison | Full method | Direct comparator |
|---|---|---|
| H1: AN-ReliefF versus Standard ReliefF | R2: AN-ReliefF plus dual-omics UA-Fusion | R3: Standard ReliefF plus dual-omics UA-Fusion |
| H2: complete dual-omics workflow versus mRNA-only | R2 | R0: mRNA-only with AN-ReliefF |
| H3: UA-Fusion versus ordinary stacking | R2 | R1: AN-ReliefF plus ordinary probability fusion |

Both geometry families are scored using the reference XGB_00. The twenty original XGBoost configurations are then evaluated on selected C0 features, and the selected classifier is shared between C0 and C2 within the same omic/context. S1/S2 candidates are evaluated afterward. Complete candidate dictionaries and the actual pooled inner-OOF scoring and tie rules are retained; winner records do not replace inner-CV selection.

The package includes the final main-result and paired-comparison Bootstrap numerical code and existing aggregate confidence intervals. It excludes earlier model-selection projects, abandoned alternatives, ancillary selector or five-class experiments, PAM50 exclusion, efficiency and visualization benchmarks, Gaussian robustness, feature-stability extensions, biological enrichment/R, old archive launchers, logs, caches, duplicated source snapshots, private audits and authorization records. Numerical dependencies previously located in predecessor directories remain included where the final pipeline calls them.

All contrasts retain R2 minus comparator. The repeat-direction heuristic is descriptive: a positive mean and at least two positive repeat differences are not statistical significance or proof of a hypothesis. The final paired Macro-F1 Bootstrap intervals for all three comparisons include zero. Bootstrap uncertainty is conditional on the saved out-of-fold predictions and observed subtype composition; it does not refit models or resample the complete training procedure.

The code accepts explicitly supplied input and output locations. The public launcher does not require an original workspace, historic file timestamps, private authorization text or prior archive/output inventories. Dataset dimensions, labels, class order, split identities, feature identities, fold membership, scientific settings, OOF exclusion and lock-before-outer-evaluation safeguards remain part of the main pipeline.

No molecular matrix, model state or patient-level prediction is included. Frozen TCGA split/cohort metadata and selected feature identifiers are part of the author-confirmed public scope. The historical table of all Meta candidate scores is omitted; the complete candidate grids and code that scores/selects them remain. The final selected-parameter table includes 15 ordinary-stacking settings and 15 settings for each of the two UA-Fusion workflows. All file-level private review records are kept outside the release directory and ZIP.
