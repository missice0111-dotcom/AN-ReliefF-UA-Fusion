# AN-ReliefF and UA-Fusion main-analysis research code

This is version `0.3.0` of the main-only research-code package. Copyright (c) 2026 Bing Zheng. The primary research code is licensed under the MIT License in `LICENSE`; third-party terms remain applicable as described in `THIRD_PARTY_NOTICES.md`. This package has been prepared locally; public repository availability has not yet been verified.

The study uses 738 TCGA-BRCA patients, mRNA and DNA methylation, and four classes in this fixed order: Luminal A (415), Luminal B (145), HER2-enriched (46), Basal-like (132). This package contains the executed main scientific implementation and its necessary local numerical dependencies, with new input routing and a public command-line entry. It retains Standard ReliefF, AN-ReliefF, native XGBoost, ordinary probability fusion, UA-Fusion, strict base out-of-fold (OOF) construction, repeated nested cross-validation, the direct H1-H3 comparisons, and the final main-result Bootstrap code. Gaussian robustness, PAM50 exclusion, enrichment and other supplemental experiments are outside this package.

H1 is R2 minus R3 (AN-ReliefF versus Standard ReliefF); H2 is R2 minus R0 (the complete dual-omics workflow versus mRNA-only); H3 is R2 minus R1 (UA-Fusion versus ordinary stacking). See `SCOPE.md` for the four method definitions.

## Installation and environment

Create an independent environment, activate it, and run these commands from this package's root:

```text
python -m venv .venv
python -m pip install -r environment/requirements-scientific.txt
python -m pip install --no-deps -e .
python -B -m brca_main --help
```

These commands describe installation for a future user. Verification of the preceding package created a new isolated environment; the original research environment was not upgraded. The CLI can also be called as `brca-main` after installation.

`config/historical_environment.json` distinguishes recorded final-main package versions from missing historical evidence. NumPy 1.26.4, pandas 2.2.2, SciPy 1.13.1, scikit-learn 1.5.1, XGBoost 2.1.1 and threadpoolctl 3.5.0 were recorded for the final main run. Author-confirmed main hardware is AMD Ryzen 9 7950X3D with 64 GB RAM. The manuscript records Windows; the exact historical main Python version and OS build remain unknown. Current verification uses a newly created isolated Python 3.12.10 environment with the recorded scientific versions and openpyxl 3.1.5. The latter is a current checked workbook-reader version; its historical-main version is unknown. LightGBM was recorded historically but is not a dependency of this final XGBoost main pipeline. `config/current_verification_environment.json` records the actual isolated verification versions, including transitive packages; these do not establish historical versions.

## Inputs and preparation

No raw or processed molecular-value matrix, trained model, or patient-level prediction is included. Supply your own permitted input files. Data-access entry points and unresolved source provenance are described in `DATA_ACCESS.md`; a related public dataset is not proof of byte identity with the paper's input.

| Argument | Required input |
|---|---|
| `--mrna` | Feature-by-sample CSV; first column is feature identifier, remaining columns are sample values on the supplied TPM scale. The accepted feature contract has 60,660 rows. |
| `--methyl` | Gzip-compressed feature-by-sample TSV of methylation beta values; first column is feature identifier. The accepted feature contract has 396,065 rows. |
| `--pam50` | Subtype workbook, sheet `TCGASubtype.20170308`, with `sampleID` and `Subtype_mRNA` columns. |
| `--cohort` | `data/cohort.tsv`: frozen 738-patient order, four-class labels, and exact mRNA/methylation raw sample-column mappings. |
| `--config` | `config/scientific_config.json`: the full frozen scientific specification, including all inner-selection candidates. |

The raw reader verifies subtype labels, primary-tumor sample mapping, dimensions, patient order, and feature-list hashes. It materializes feature-major `<f4` NumPy arrays in the frozen patient order. Raw preparation performs no training-fold transformation or model fitting. Generated `dataset.json` refers to its matrix and feature files by relative names and records input filenames and checksums.

Example, using relative paths chosen by the user:

```text
python -B -m brca_main prepare --mrna inputs/mrna.csv --methyl inputs/methyl.tsv.gz --pam50 inputs/subtypes.xlsx --cohort data/cohort.tsv --config config/scientific_config.json --output work/prepared
```

The feature and cohort contract intentionally matches the final paper; this is not a general arbitrary-cohort workflow. Different molecular values that satisfy the contract remain user-supplied inputs. Contract conformity does not establish equivalence to the paper's molecular matrices or results. Full source feature lists are generated from input; only the final selected-feature lists and their context identities are distributed in `data/selected_features.tsv`.

## Training and metric summary

Full training is explicitly invoked as follows. This command is expensive and was **NOT_RUN** during release preparation:

```text
python -B -m brca_main train --inputs work/prepared/dataset.json --config config/scientific_config.json --cohort data/cohort.tsv --splits data/splits.json --output work/main_run
```

The entry validates the scientific configuration and frozen split contents before fitting. It uses the retained three repeats, five outer folds, and three inner folds. No partition or candidate bank is regenerated. Outputs must be new or empty; the CLI rejects overwriting supplied input/source locations. The public entry binds the supplied inputs, scientific settings, frozen splits and local source checksums instead of requiring historical workspace paths, private authorization records or archived file inventories.

Training-fold preprocessing, missing-value handling, mRNA `log2(x+1)`, scaling, ANOVA, geometry and ranking are the actual accepted numerical implementations. mRNA uses training-fitted median imputation and training z-scaling; methylation uses training-fitted median imputation and unscaled beta values. The original raw-feature blocks, float64 intermediate arithmetic and float32 model matrices remain unchanged. Preprocessing and feature selection are fitted only on the corresponding training patients.

Within each omic/context, C0 and C2 geometry candidates are scored first at reference `XGB_00`; the twenty XGBoost candidates are then scored on the selected C0 features. The winning XGBoost setting is shared by C0 and C2. Strict base OOF probabilities feed the retained S1/S2 meta-selection procedure. The meta models are selected on the existing inner slices of those base OOF matrices, as in the actual main implementation. Parameters and models are locked before accessing outer predictions; all four method predictions are locked before outer-label evaluation.

The released specification contains all 16 C0, 144 C2, 20 XGBoost, 10 S1 and 70 S2 candidates, candidate order, pooled inner-OOF Macro-F1 score, feasibility rules, selection sequence and tie rules. Geometry ties within `1e-12` use smaller `(top_m, k, c0/r0, config_id)`; XGBoost ties use smaller candidate index. S1 ties use `(C, meta_scaling, config_id)` and S2 ties use `(n_uncertainty, C, meta_scaling, subset_id)`. Source code and the specification govern the exact implementation.

The three model seeds are `2026092401`, `2026092402`, `2026092403`; outer split seeds are `2026100821`, `2026100822`, `2026100823`. The recorded inner seed rule is `2026101200 + 100*repeat + outer_fold`. The frozen patient partitions are supplied in `data/splits.json`.

Training automatically creates aggregate tables. For a user-owned completed run containing full-precision `parts/r1_o1/predictions.tsv` through `parts/r3_o5/predictions.tsv`, metric-only summarization is:

```text
python -B -m brca_main summarize --run work/main_run --cohort data/cohort.tsv --splits data/splits.json --output work/summary
```

This command performs no model fitting or prediction. It validates four methods, frozen outer test membership, true labels, probability validity, 738-patient repeat coverage and duplicate exclusion. It pools five outer folds within each repeat and summarizes three repeat estimates with sample SD (`ddof=1`). Metrics retain the actual Macro-F1, accuracy, balanced accuracy, mean four one-versus-rest AUCs, log loss, and multiclass Brier score (patient mean of the sum of four squared errors). Direct H1-H3 tables contain the three paired repeat differences. The accompanying repeat-direction JSON is descriptive: a positive mean and at least two positive repeat differences are not statistical significance or hypothesis proof. Patient predictions required for this command are not distributed.

## Final main-result Bootstrap

The `bootstrap` entry extracts the actual final statistical script's numerical functions and computation block. It accepts either a merged full-precision TSV/TSV.GZ or a user-owned completed run with the 15 outer-fold prediction files:

```text
python -B -m brca_main bootstrap --predictions inputs/outer_oof_predictions.tsv --cohort data/cohort.tsv --splits data/splits.json --output work/bootstrap
```

Alternatively replace `--predictions inputs/outer_oof_predictions.tsv` with `--run work/main_run`. Required prediction columns are `variant`, `repeat`, `outer_fold`, `patient_id`, `true_label`, `predicted_label`, and `probability::Luminal A`, `probability::Luminal B`, `probability::HER2-enriched`, `probability::Basal-like`. Labels are integer class indices 0 to 3 in the fixed class order. There must be all 8,856 rows: four methods times three repeats times 738 patients, with the exact frozen labels/folds and one row per method-repeat-patient. Probabilities remain full precision and are not renormalized. Input checks occur before resampling and output creation.

The fixed analysis performs 1,000 patient-cluster resamples using `numpy.random.Generator(PCG64)` and seed `2026100901`. Within each true subtype, it samples the original number of patient IDs with replacement. Each resulting 738-element multiplicity vector is shared across all four workflows and all three repeats. Each metric and paired Macro-F1 difference is calculated separately within each repeat and then averaged across three repeats. The 95% intervals are the 2.5th/97.5th percentiles using NumPy's `method="linear"`. The original patient sort order, sampling class order, equal-score AUC tie handling, zero-division rule and original comparison order are preserved in code and `config/bootstrap_protocol.json`.

The final Bootstrap covers Macro-F1, accuracy, balanced accuracy, Macro-AUROC, subtype precision/recall/F1, and the three paired Macro-F1 differences. The main reporting code additionally retains log loss and Brier point estimates; no new Bootstrap method for those metrics is introduced. These intervals are conditional on saved OOF prediction vectors and observed subtype composition; they do not quantify the uncertainty of retraining or hyperparameter selection. No model is refitted and no hypothesis test or p-value is added. All three existing primary difference intervals include zero. The supplied aggregate interval tables are copied from the final analysis; this release preparation did not recompute them.

The command writes aggregate intervals and user-generated resampling arrays into the specified new output directory. Those generated arrays and patient-associated files are excluded from this release and ignored by `.gitignore`. Neither a molecular matrix nor a fitted model is required for statistical summarization, but user-provided patient predictions are required and are not bundled.

## File and scientific provenance

- `src/brca_main/`: scientific code and the new public routing/guards.
- `config/`: full scientific candidate space, input schema, historical version evidence.
- `data/`: cohort/sample mapping, frozen partitions, selected feature identifiers and hashes.
- `reference_results/`: retained aggregate main metrics, direct contrasts, final Bootstrap intervals and selected inner-CV parameters; no patient predictions or fitted coefficients. `selection/meta_selected_by_outer.tsv` contains the 15 final ordinary-stacking settings and 15 settings for each of the two UA-Fusion workflows; fixed logistic-regression parameters are in the full scientific config. The historical all-candidate Meta score table is omitted; fresh training still generates scores and executes full inner selection.
- `provenance/`: safe relative source identifiers, before/after checksums and numerical-source provenance. Detailed scientific-equivalence checks remain in the separate private review; their scope is summarized in `VALIDATION.md`.
- `FILE_MANIFEST.tsv`: file sizes and SHA256 values for all other package files; the manifest excludes itself to avoid a self-referential hash. The ZIP checksum is supplied separately beside the ZIP.

The accepted preprocessing source was the implementation actually used by the current final main run. Its own historical provenance reports that an earlier unavailable FoldPreprocessor implementation was reconstructed before that run; source-byte parity with that earlier missing implementation is not claimed. This release reuses the accepted implementation and does not create a new approximate algorithm.

`CHANGES.md` describes retained, omitted and modified categories. Detailed local audit records are outside this directory and ZIP.

## Verification and remaining limits

See `VALIDATION.md` for the completed checks and their precise boundaries. Installation/import/help success is not an end-to-end reproduction claim. Raw preparation, all model fitting, hyperparameter search, full nested CV, prediction, metric recomputation, and real-data Bootstrap are **NOT_RUN** for this package. The supplied reference tables are existing results.

Remaining requirements for an independent paper-result rerun are permitted matching molecular inputs and clarification of the unresolved upstream input/export chain. End-to-end execution has not been tested here. The author has confirmed the MIT License and the included roster/features/results scope; public repository availability is not yet verified. No model/data/prediction attachment is prepared or published with this package.
